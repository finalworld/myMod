package se.bubbsun.app

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID
import kotlin.math.abs

private val listIcons = listOf("🛒","🧺","🍎","🍴","🏋","🏃","🚲","🥾","💼","💻","📚","✏","🏠","🛋","🐾","♥")
private val iconColors = listOf(0xFF2B6F73,0xFF9B3F2D,0xFF597A3B,0xFF8C6337,0xFF50677A,0xFF7A6B3B)

data class UserProfile(val id:String=UUID.randomUUID().toString(), var name:String, var colorHex:Long)
class ShoppingItem(
    val id:String=UUID.randomUUID().toString(), name:String, quantity:String="", ownerId:String,
    completed:Boolean=false, val createdAt:Long=System.currentTimeMillis(), completedAt:Long?=null
){ var name by mutableStateOf(name); var quantity by mutableStateOf(quantity); var ownerId by mutableStateOf(ownerId); var completed by mutableStateOf(completed); var completedAt by mutableStateOf(completedAt) }
class ShoppingListData(
    val id:String=UUID.randomUUID().toString(), name:String, icon:String="🛒", iconColorHex:Long=0xFF2B6F73,
    items:List<ShoppingItem> = emptyList()
){ var name by mutableStateOf(name); var icon by mutableStateOf(icon); var iconColorHex by mutableStateOf(iconColorHex); val items=mutableStateListOf<ShoppingItem>().apply{addAll(items)} }
data class StatEvent(val id:String=UUID.randomUUID().toString(),val kind:String,val itemName:String,val userId:String,val timestamp:Long=System.currentTimeMillis())

class MainActivity:ComponentActivity(){ override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);setContent{BubbsunApp(applicationContext)}} }

private class BubbsunStore(context:Context){
    private val prefs=context.getSharedPreferences("bubbsun_store",Context.MODE_PRIVATE)
    fun loadUsers():MutableList<UserProfile>{
        val raw=prefs.getString("users_v010",null)?:return mutableListOf(UserProfile("danne","Danne",0xFFFFC928),UserProfile("sanja","Sanja",0xFFFF5E8A))
        return runCatching{val a=JSONArray(raw);MutableList(a.length()){i->val o=a.getJSONObject(i);UserProfile(o.getString("id"),o.getString("name"),o.getLong("color"))}}.getOrElse{mutableListOf(UserProfile("danne","Danne",0xFFFFC928),UserProfile("sanja","Sanja",0xFFFF5E8A))}
    }
    fun saveUsers(users:List<UserProfile>){val a=JSONArray();users.forEach{u->a.put(JSONObject().apply{put("id",u.id);put("name",u.name);put("color",u.colorHex)})};prefs.edit().putString("users_v010",a.toString()).apply()}
    fun loadLists(users:List<UserProfile>):MutableList<ShoppingListData>{
        val raw=prefs.getString("lists",null)?:return mutableListOf(ShoppingListData(name="Matinköp",icon="🛒"),ShoppingListData(name="Träning",icon="🏋",iconColorHex=0xFF597A3B))
        val danne=users.firstOrNull{it.name.equals("Danne",true)}?.id?:users.first().id;val sanja=users.firstOrNull{it.name.equals("Sanja",true)}?.id?:users.first().id
        return runCatching{val a=JSONArray(raw);MutableList(a.length()){i->val o=a.getJSONObject(i);val loaded=mutableListOf<ShoppingItem>();val ia=o.optJSONArray("items")?:JSONArray();repeat(ia.length()){j->val it=ia.getJSONObject(j);val legacy=it.optString("owner","DANNE");loaded+=ShoppingItem(it.optString("id",UUID.randomUUID().toString()),it.optString("name",""),it.optString("quantity",""),it.optString("ownerId",if(legacy=="SANJA")sanja else danne),it.optBoolean("completed",false),it.optLong("createdAt",System.currentTimeMillis()),if(it.isNull("completedAt"))null else it.optLong("completedAt"))};ShoppingListData(o.optString("id",UUID.randomUUID().toString()),o.optString("name","Lista"),o.optString("icon",listIcons[i%listIcons.size]),o.optLong("iconColor",iconColors[i%iconColors.size]),loaded)}}.getOrElse{mutableListOf(ShoppingListData(name="Matinköp"))}
    }
    fun saveLists(lists:List<ShoppingListData>){val a=JSONArray();lists.forEach{l->val ia=JSONArray();l.items.forEach{it->ia.put(JSONObject().apply{put("id",it.id);put("name",it.name);put("quantity",it.quantity);put("ownerId",it.ownerId);put("completed",it.completed);put("createdAt",it.createdAt);put("completedAt",it.completedAt?:JSONObject.NULL)})};a.put(JSONObject().apply{put("id",l.id);put("name",l.name);put("icon",l.icon);put("iconColor",l.iconColorHex);put("items",ia)})};prefs.edit().putString("lists",a.toString()).apply()}
    fun loadEvents():MutableList<StatEvent>{val raw=prefs.getString("events_v010",null)?:return mutableListOf();return runCatching{val a=JSONArray(raw);MutableList(a.length()){i->val o=a.getJSONObject(i);StatEvent(o.getString("id"),o.getString("kind"),o.getString("itemName"),o.optString("userId",""),o.getLong("timestamp"))}}.getOrElse{mutableListOf()}}
    fun saveEvents(events:List<StatEvent>){val a=JSONArray();events.forEach{e->a.put(JSONObject().apply{put("id",e.id);put("kind",e.kind);put("itemName",e.itemName);put("userId",e.userId);put("timestamp",e.timestamp)})};prefs.edit().putString("events_v010",a.toString()).apply()}
    fun loadDark()=prefs.getBoolean("dark",true);fun saveDark(v:Boolean)=prefs.edit().putBoolean("dark",v).apply();fun loadUserId(d:String)=prefs.getString("active_user_v010",d)?:d;fun saveUserId(id:String)=prefs.edit().putString("active_user_v010",id).apply()
}

data class Palette(
    val bg:Color,val top:Color,val panel:Color,val paper:Color,val paper2:Color,
    val text:Color,val pageText:Color,val muted:Color,val pageMuted:Color,
    val gold:Color,val green:Color,val red:Color,val outline:Color,val glow:Color
)
private val lightPalette=Palette(
    Color(0xFFB6915D),Color(0xFF2C2118),Color(0xFF3A2B1C),Color(0xFFE9D7A8),Color(0xFFDCC28B),
    Color(0xFF2A2119),Color(0xFF2A2119),Color(0xFF6D5B42),Color(0xFF5B482F),
    Color(0xFFD4A93A),Color(0xFF315F5C),Color(0xFFA83A28),Color(0xFF60451F),Color(0xFFFFD85E)
)
private val darkPalette=Palette(
    Color(0xFF15120E),Color(0xFF211911),Color(0xFF2A2118),Color(0xFFD8C294),Color(0xFFC9AC76),
    Color(0xFF261E16),Color(0xFFF2E2BC),Color(0xFF65543E),Color(0xFFC8B894),
    Color(0xFFD6A83D),Color(0xFF294F4D),Color(0xFFAA3C2C),Color(0xFF6E5328),Color(0xFFFFD85E)
)
private val userColors=listOf(0xFFFFC928,0xFFFF5E8A,0xFFFF8A2B,0xFFE84B3C,0xFF9E3F45,0xFF7846A8,0xFF3487C7,0xFF35AFC2,0xFF3BA78F,0xFF7BAD43,0xFFB4D936,0xFF8A5B35,0xFFD8B98A,0xFF244F73,0xFF9DD8B7,0xFF777777)

@Composable fun BubbsunApp(context:Context){
    val store=remember{BubbsunStore(context)};val users=remember{mutableStateListOf<UserProfile>().apply{addAll(store.loadUsers())}};val lists=remember{mutableStateListOf<ShoppingListData>().apply{addAll(store.loadLists(users))}};val events=remember{mutableStateListOf<StatEvent>().apply{addAll(store.loadEvents())}}
    var activeUserId by remember{mutableStateOf(store.loadUserId(users.first().id))};var dark by remember{mutableStateOf(store.loadDark())};var screen by remember{mutableStateOf("lists")};var selectedListId by remember{mutableStateOf<String?>(null)};var menuOpen by remember{mutableStateOf(false)};val p=if(dark)darkPalette else lightPalette
    BackHandler(enabled=menuOpen||screen!="lists"){if(menuOpen)menuOpen=false else{screen="lists";selectedListId=null}}
    MaterialTheme(colorScheme=if(dark)darkColorScheme() else lightColorScheme()){
        Box(Modifier.fillMaxSize().background(p.bg).safeDrawingPadding()){
            Column(Modifier.fillMaxSize()){
                AppHeader(dark,p,onMenu={menuOpen=true},onTheme={dark=!dark;store.saveDark(dark)})
                when(screen){
                    "lists"->ListsScreen(lists,p,onOpen={selectedListId=it;screen="list"},onAdd={screen="addList"},onSave={store.saveLists(lists)})
                    "addList"->AddListScreen(p,onBack={screen="lists"},onCreate={name,icon,color->lists.add(0,ShoppingListData(name=capitalized(name),icon=icon,iconColorHex=color));store.saveLists(lists);screen="lists"})
                    "stats"->StatsScreen(lists,events,users,p,onBack={screen="lists"},onReset={events.clear();store.saveEvents(events)})
                    "users"->UsersScreen(users,activeUserId,p,onBack={screen="lists"},onActivate={activeUserId=it;store.saveUserId(it)},onSave={if(users.none{it.id==activeUserId})activeUserId=users.first().id;store.saveUsers(users);store.saveUserId(activeUserId)})
                    "about"->AboutScreen(p,onBack={screen="lists"})
                    else->{val l=lists.firstOrNull{it.id==selectedListId};if(l==null)screen="lists" else ShoppingListScreen(l,users,activeUserId,p,onBack={screen="lists"},onSave={store.saveLists(lists)},onEvent={events.add(it);store.saveEvents(events)})}
                }
            }
            if(menuOpen)SideMenu(users,activeUserId,p,onClose={menuOpen=false},onActivate={activeUserId=it;store.saveUserId(it)},onNavigate={menuOpen=false;screen=it})
        }
    }
}

@Composable private fun AppHeader(dark:Boolean,p:Palette,onMenu:()->Unit,onTheme:()->Unit){
    Row(Modifier.fillMaxWidth().background(p.top).padding(horizontal=12.dp,vertical=10.dp),verticalAlignment=Alignment.CenterVertically){
        SquareIcon("☰",onMenu,p,large=true);Spacer(Modifier.width(12.dp));Column(Modifier.weight(1f),horizontalAlignment=Alignment.CenterHorizontally){Text("Bubbsun",fontFamily=FontFamily.Cursive,fontStyle=FontStyle.Italic,fontWeight=FontWeight.Black,fontSize=38.sp,color=Color(0xFFC94F32),modifier=Modifier.shadow(1.dp));Text("★  LISTOR MED KARAKTÄR  ★",fontFamily=FontFamily.Serif,fontWeight=FontWeight.Bold,fontSize=10.sp,color=p.gold)};Spacer(Modifier.width(8.dp));SquareIcon(if(dark)"☀" else "☾",onTheme,p,large=true)
    }
}

@Composable private fun SideMenu(users:List<UserProfile>,activeId:String,p:Palette,onClose:()->Unit,onActivate:(String)->Unit,onNavigate:(String)->Unit){
    var chooser by remember{mutableStateOf(false)};Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha=.58f)).clickable{onClose()}){Column(Modifier.fillMaxHeight().fillMaxWidth(.78f).background(p.top).padding(18.dp).clickable(enabled=false){},verticalArrangement=Arrangement.Top){Row(verticalAlignment=Alignment.CenterVertically){Text("Bubbsun",fontFamily=FontFamily.Cursive,fontStyle=FontStyle.Italic,fontWeight=FontWeight.Black,fontSize=34.sp,color=Color(0xFFC94F32),modifier=Modifier.weight(1f));SquareIcon("×",onClose,p,large=true)};Spacer(Modifier.height(24.dp));Text("AKTIV ANVÄNDARE",fontWeight=FontWeight.Black,fontSize=13.sp,color=p.gold);Spacer(Modifier.height(8.dp));Box{val active=users.firstOrNull{it.id==activeId}?:users.first();MenuRow("●",active.name,"›",p,iconColor=Color(active.colorHex)){chooser=true};DropdownMenu(chooser,{chooser=false}){users.forEach{u->DropdownMenuItem(text={Text(u.name)},onClick={onActivate(u.id);chooser=false},leadingIcon={Box(Modifier.size(18.dp).clip(CircleShape).background(Color(u.colorHex)))})}}};Spacer(Modifier.height(15.dp));MenuRow("♙","Lägg till användare","",p){onNavigate("users")};MenuRow("▥","Statistik","",p){onNavigate("stats")};HorizontalDivider(color=p.outline,modifier=Modifier.padding(vertical=14.dp));MenuRow("ⓘ","Om","",p){onNavigate("about")}}
    }
}

@Composable private fun MenuRow(icon:String,label:String,end:String,p:Palette,iconColor:Color=p.gold,onClick:()->Unit){Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp)).clickable{onClick()}.padding(vertical=13.dp,horizontal=8.dp),verticalAlignment=Alignment.CenterVertically){Text(icon,fontSize=26.sp,color=iconColor);Spacer(Modifier.width(14.dp));Text(label,fontFamily=FontFamily.Serif,fontWeight=FontWeight.Bold,fontSize=19.sp,color=Color(0xFFEAD7A8),modifier=Modifier.weight(1f));Text(end,fontSize=28.sp,color=Color(0xFFEAD7A8))}}

@Composable private fun ListsScreen(lists:SnapshotStateList<ShoppingListData>,p:Palette,onOpen:(String)->Unit,onAdd:()->Unit,onSave:()->Unit){
    var deleteTarget by remember{mutableStateOf<ShoppingListData?>(null)};var draggingId by remember{mutableStateOf<String?>(null)}
    Column(Modifier.fillMaxSize().padding(12.dp)){RetroTitle("★  DINA LISTOR  ★",p);Spacer(Modifier.height(10.dp));LazyColumn(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(7.dp)){items(lists,key={it.id}){l->ListRow(l,p,dragging=draggingId==l.id,onOpen={onOpen(l.id)},onDelete={deleteTarget=l},onDragStart={draggingId=l.id},onDragEnd={draggingId=null},onMove={dir->val from=lists.indexOf(l);val to=(from+dir).coerceIn(0,lists.lastIndex);if(from!=to){lists.removeAt(from);lists.add(to,l);onSave()}})}};RetroButton("＋  LÄGG TILL NY LISTA",onAdd,p,modifier=Modifier.fillMaxWidth())}
    deleteTarget?.let{l->ConfirmDialog("Ta bort listan \"${l.name}\"?","Alla saker i listan försvinner.",p,{deleteTarget=null},{lists.remove(l);deleteTarget=null;onSave()})}
}

@Composable private fun ListRow(list:ShoppingListData,p:Palette,dragging:Boolean,onOpen:()->Unit,onDelete:()->Unit,onDragStart:()->Unit,onDragEnd:()->Unit,onMove:(Int)->Unit){
    val haptic=LocalHapticFeedback.current;var drag by remember{mutableStateOf(0f)};val bg by animateColorAsState(if(dragging)p.glow else p.paper,label="drag")
    Row(Modifier.fillMaxWidth().shadow(if(dragging)9.dp else 2.dp,RoundedCornerShape(10.dp)).clip(RoundedCornerShape(10.dp)).background(bg).border(if(dragging)3.dp else 2.dp,if(dragging)p.gold else p.outline,RoundedCornerShape(10.dp)),verticalAlignment=Alignment.CenterVertically){
        Row(Modifier.width(90.dp).height(78.dp).background(Color(list.iconColorHex)).pointerInput(list.id){detectDragGesturesAfterLongPress(onDragStart={haptic.performHapticFeedback(HapticFeedbackType.LongPress);onDragStart();drag=0f},onDragEnd={onDragEnd();drag=0f},onDragCancel={onDragEnd();drag=0f},onDrag={change,amount->change.consume();drag+=amount.y;if(abs(drag)>46){onMove(if(drag>0)1 else -1);drag=0f}})},verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.SpaceEvenly){Text("⠿",fontSize=27.sp,color=Color(0xFFEAD7A8));Text(list.icon,fontSize=31.sp)}
        Column(Modifier.weight(1f).clickable{onOpen()}.padding(horizontal=14.dp,vertical=10.dp)){Text(list.name,fontFamily=FontFamily.Serif,fontWeight=FontWeight.Black,fontSize=21.sp,color=p.text);Text("${list.items.size} objekt",fontWeight=FontWeight.Bold,color=p.text)}
        DeleteButton(onDelete,p);Text("›",fontSize=35.sp,fontWeight=FontWeight.Bold,color=p.text,modifier=Modifier.clickable{onOpen()}.padding(horizontal=10.dp))
    }
}

@Composable private fun AddListScreen(p:Palette,onBack:()->Unit,onCreate:(String,String,Long)->Unit){
    var name by remember{mutableStateOf("")};var icon by remember{mutableStateOf(listIcons.first())};var color by remember{mutableStateOf(iconColors.first())}
    Column(Modifier.fillMaxSize().padding(14.dp)){
        PageHeader("LÄGG TILL NY LISTA",p,onBack)
        Spacer(Modifier.height(12.dp))
        LazyColumn(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(10.dp)){
            item{Text("LISTNAMN",fontWeight=FontWeight.Black,color=p.pageText)}
            item{RetroField(name,{name=it},"Skriv listans namn…",Modifier.fillMaxWidth(),p)}
            item{Text("VÄLJ IKON",fontWeight=FontWeight.Black,color=p.pageText)}
            items(listIcons.chunked(4)){row->
                Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(9.dp)){
                    row.forEach{i->val selected=i==icon;Box(Modifier.weight(1f).aspectRatio(1f).clip(RoundedCornerShape(9.dp)).background(if(selected)Color(color) else p.paper).border(if(selected)3.dp else 2.dp,if(selected)p.gold else p.outline,RoundedCornerShape(9.dp)).clickable{icon=i}.padding(8.dp),contentAlignment=Alignment.Center){Text(i,fontSize=30.sp)}}
                }
            }
            item{Text("VÄLJ FÄRG",fontWeight=FontWeight.Black,color=p.pageText)}
            item{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){iconColors.forEach{c->Box(Modifier.size(43.dp).clip(CircleShape).background(Color(c)).border(if(c==color)4.dp else 1.dp,if(c==color)p.gold else p.outline,CircleShape).clickable{color=c})}}}
            item{Spacer(Modifier.height(4.dp))}
        }
        Spacer(Modifier.height(10.dp))
        RetroButton("SKAPA LISTA",{if(name.isNotBlank())onCreate(name,icon,color)},p,modifier=Modifier.fillMaxWidth())
    }
}

@Composable
private fun ShoppingListScreen(
    list: ShoppingListData,
    users: List<UserProfile>,
    activeUserId: String,
    p: Palette,
    onBack: () -> Unit,
    onSave: () -> Unit,
    onEvent: (StatEvent) -> Unit
) {
    var input by remember { mutableStateOf("") }
    var quantityInput by remember { mutableStateOf("") }
    var showDone by remember { mutableStateOf(true) }
    var editing by remember { mutableStateOf<ShoppingItem?>(null) }
    var deleteMode by remember { mutableStateOf(false) }
    val selected = remember { mutableStateListOf<String>() }
    var confirmDelete by remember { mutableStateOf(false) }
    var draggingId by remember { mutableStateOf<String?>(null) }

    val active = list.items.filter { !it.completed }
    val done = list.items
        .filter { it.completed }
        .sortedByDescending { it.completedAt ?: 0L }

    fun save() {
        onSave()
    }

    fun addItem(raw: String, quantity: String = quantityInput) {
        val name = capitalized(raw)
        if (name.isBlank()) return

        val existing = list.items.firstOrNull { it.name.equals(name, ignoreCase = true) }
        if (existing == null) {
            list.items.add(0, ShoppingItem(name = name, quantity = quantity.trim(), ownerId = activeUserId))
        } else {
            existing.completed = false
            existing.completedAt = null
            existing.ownerId = activeUserId
            existing.quantity = quantity.trim()
            list.items.remove(existing)
            list.items.add(0, existing)
        }

        input = ""
        quantityInput = ""
        save()
    }

    Column(
        Modifier
            .fillMaxSize()
            .imePadding()
            .padding(12.dp)
    ) {
        PageHeader(
            title = list.name,
            p = p,
            onBack = onBack,
            trailing = {
                DeleteButton(
                    onClick = {
                        if (deleteMode) {
                            if (selected.isEmpty()) {
                                deleteMode = false
                            } else {
                                confirmDelete = true
                            }
                        } else {
                            deleteMode = true
                        }
                    },
                    p = p
                )
            }
        )

        Spacer(Modifier.height(10.dp))

        Row(verticalAlignment = Alignment.CenterVertically) {
            RetroField(
                value = input,
                onValueChange = { input = it },
                placeholder = "Vara…",
                modifier = Modifier.weight(1.65f),
                p = p,
                onDone = { addItem(input) }
            )
            Spacer(Modifier.width(7.dp))
            RetroField(
                value = quantityInput,
                onValueChange = { quantityInput = it },
                placeholder = "Valfri…",
                modifier = Modifier.weight(.72f),
                p = p,
                onDone = { addItem(input) }
            )
            Spacer(Modifier.width(7.dp))
            RetroButton("✓", { addItem(input) }, p, compact = true)
        }

        Spacer(Modifier.height(10.dp))

        if (deleteMode) {
            val allIds = list.items.map { it.id }
            val allSelected = allIds.isNotEmpty() && selected.containsAll(allIds)
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp)).background(p.panel).padding(horizontal=10.dp, vertical=8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Checkbox(
                    checked = allSelected,
                    onCheckedChange = {
                        selected.clear()
                        if (!allSelected) selected.addAll(allIds)
                    },
                    colors = CheckboxDefaults.colors(checkedColor=p.red, uncheckedColor=p.pageText, checkmarkColor=Color.White)
                )
                Text("MARKERA ALLA",fontFamily=FontFamily.Serif,fontWeight=FontWeight.Black,color=p.pageText,modifier=Modifier.clickable{
                    selected.clear(); if(!allSelected) selected.addAll(allIds)
                })
                Spacer(Modifier.weight(1f))
                Text("AVBRYT",fontWeight=FontWeight.Black,color=p.gold,modifier=Modifier.clickable{selected.clear();deleteMode=false}.padding(8.dp))
            }
            Spacer(Modifier.height(8.dp))
        }

        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            items(active, key = { it.id }) { item ->
                ItemRow(
                    item = item,
                    users = users,
                    p = p,
                    deleteMode = deleteMode,
                    isSelected = selected.contains(item.id),
                    dragging = draggingId == item.id,
                    onSelect = {
                        if (item.id in selected) selected.remove(item.id) else selected.add(item.id)
                    },
                    onToggle = {
                        item.completed = true
                        item.completedAt = System.currentTimeMillis()
                        onEvent(
                            StatEvent(
                                kind = "purchase",
                                itemName = item.name,
                                userId = item.ownerId
                            )
                        )
                        save()
                    },
                    onEdit = { editing = item },
                    onDragStart = { draggingId = item.id },
                    onDragEnd = { draggingId = null },
                    onMove = { direction ->
                        val current = list.items.filter { !it.completed }
                        val from = current.indexOf(item)
                        val to = (from + direction).coerceIn(0, current.lastIndex)
                        if (from != to) {
                            val other = current[to]
                            val firstIndex = list.items.indexOf(item)
                            val secondIndex = list.items.indexOf(other)
                            list.items[firstIndex] = other
                            list.items[secondIndex] = item
                            save()
                        }
                    }
                )
            }

            item {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(p.green)
                        .clickable { showDone = !showDone }
                        .padding(10.dp)
                ) {
                    Text(
                        text = if (showDone) "KLART (${done.size})  ▲" else "KLART (${done.size})  ▼",
                        fontFamily = FontFamily.Serif,
                        fontWeight = FontWeight.Black,
                        color = Color.White
                    )
                }
            }

            if (showDone) {
                items(done, key = { "d${it.id}" }) { item ->
                    ItemRow(
                        item = item,
                        users = users,
                        p = p,
                        deleteMode = deleteMode,
                        isSelected = selected.contains(item.id),
                        dragging = false,
                        onSelect = {
                            if (item.id in selected) selected.remove(item.id) else selected.add(item.id)
                        },
                        onToggle = {
                            item.completed = false
                            item.completedAt = null
                            list.items.remove(item)
                            list.items.add(0, item)
                            save()
                        },
                        onEdit = { editing = item },
                        onDragStart = {},
                        onDragEnd = {},
                        onMove = {}
                    )
                }
            }
        }

    }

    editing?.let { item ->
        EditDialog(
            item = item,
            p = p,
            onDismiss = { editing = null },
            onSave = { newName, newQuantity ->
                item.name = capitalized(newName)
                item.quantity = newQuantity.trim()
                editing = null
                save()
            }
        )
    }

    if (confirmDelete) {
        ConfirmDialog(
            title = "Ta bort ${selected.size} markerade saker?",
            text = "Det går inte att ångra.",
            p = p,
            onDismiss = { confirmDelete = false },
            onConfirm = {
                val doomed = list.items.filter { it.id in selected }
                doomed.forEach { item ->
                    onEvent(
                        StatEvent(
                            kind = "delete",
                            itemName = item.name,
                            userId = item.ownerId
                        )
                    )
                }
                list.items.removeAll(doomed)
                selected.clear()
                deleteMode = false
                confirmDelete = false
                save()
            }
        )
    }
}

@Composable private fun ItemRow(item:ShoppingItem,users:List<UserProfile>,p:Palette,deleteMode:Boolean,isSelected:Boolean,dragging:Boolean,onSelect:()->Unit,onToggle:()->Unit,onEdit:()->Unit,onDragStart:()->Unit,onDragEnd:()->Unit,onMove:(Int)->Unit){
    val haptic=LocalHapticFeedback.current
    var drag by remember{mutableStateOf(0f)}
    val bg by animateColorAsState(if(dragging)p.glow else p.paper,label="itemdrag")
    val owner=users.firstOrNull{it.id==item.ownerId}
    val darkTheme=p.bg.luminance()<0.25f
    Row(Modifier.fillMaxWidth().shadow(if(dragging)8.dp else 1.dp,RoundedCornerShape(8.dp)).clip(RoundedCornerShape(8.dp)).background(bg).border(if(dragging)3.dp else 1.dp,if(dragging)p.gold else p.outline,RoundedCornerShape(8.dp)),verticalAlignment=Alignment.CenterVertically){
        if(owner!=null) Box(Modifier.width(8.dp).height(66.dp).background(Color(owner.colorHex)))
        Checkbox(
            checked=item.completed,
            onCheckedChange={onToggle()},
            colors=CheckboxDefaults.colors(
                checkedColor=p.green,
                uncheckedColor=if(darkTheme) Color(0xFF17130F) else p.outline,
                checkmarkColor=Color(0xFFF4E4BA)
            )
        )
        Spacer(Modifier.width(3.dp))
        Column(Modifier.weight(1f).clickable{onEdit()}.padding(vertical=9.dp)){
            Text(item.name,fontFamily=FontFamily.Serif,fontWeight=FontWeight.Bold,fontSize=18.sp,color=p.text,textDecoration=if(item.completed)TextDecoration.LineThrough else null)
            if(item.quantity.isNotBlank()) Text(item.quantity,fontSize=13.sp,fontWeight=FontWeight.Bold,color=p.muted)
        }
        if(deleteMode) Checkbox(isSelected,{onSelect()},colors=CheckboxDefaults.colors(checkedColor=p.red,uncheckedColor=if(darkTheme) Color(0xFF17130F) else p.outline,checkmarkColor=Color.White))
        else if(!item.completed) Text("⠿",fontSize=27.sp,color=p.muted,modifier=Modifier.padding(12.dp).pointerInput(item.id){detectDragGesturesAfterLongPress(onDragStart={haptic.performHapticFeedback(HapticFeedbackType.LongPress);onDragStart();drag=0f},onDragEnd={onDragEnd();drag=0f},onDragCancel={onDragEnd();drag=0f},onDrag={change,amount->change.consume();drag+=amount.y;if(abs(drag)>42){onMove(if(drag>0)1 else -1);drag=0f}})})
    }
}

@Composable private fun UsersScreen(users:SnapshotStateList<UserProfile>,activeId:String,p:Palette,onBack:()->Unit,onActivate:(String)->Unit,onSave:()->Unit){
    var showAdd by remember{mutableStateOf(false)};var deleteTarget by remember{mutableStateOf<UserProfile?>(null)};Column(Modifier.fillMaxSize().padding(14.dp)){PageHeader("ANVÄNDARE",p,onBack);Spacer(Modifier.height(12.dp));LazyColumn(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(8.dp)){items(users,key={it.id}){u->Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(p.paper).border(if(u.id==activeId)3.dp else 2.dp,if(u.id==activeId)p.gold else p.outline,RoundedCornerShape(10.dp)).clickable{onActivate(u.id)}.padding(13.dp),verticalAlignment=Alignment.CenterVertically){Box(Modifier.size(30.dp).clip(CircleShape).background(Color(u.colorHex)));Spacer(Modifier.width(12.dp));Column(Modifier.weight(1f)){Text(u.name,fontFamily=FontFamily.Serif,fontWeight=FontWeight.Black,fontSize=20.sp,color=p.text);if(u.id==activeId)Text("Aktiv användare",color=p.muted)};if(users.size>1)DeleteButton({deleteTarget=u},p)}}};RetroButton("＋  LÄGG TILL ANVÄNDARE",{showAdd=true},p,modifier=Modifier.fillMaxWidth())};if(showAdd)AddUserDialog(users,p,{showAdd=false},{n,c->users.add(UserProfile(name=capitalized(n),colorHex=c));showAdd=false;onSave()});deleteTarget?.let{u->ConfirmDialog("Ta bort ${u.name}?","Användaren tas bort.",p,{deleteTarget=null},{users.remove(u);deleteTarget=null;onSave()})}
}

@Composable private fun AddUserDialog(users:List<UserProfile>,p:Palette,onDismiss:()->Unit,onAdd:(String,Long)->Unit){var name by remember{mutableStateOf("")};var color by remember{mutableStateOf(userColors.first())};var error by remember{mutableStateOf("")};AlertDialog(onDismissRequest=onDismiss,containerColor=p.paper,title={Text("LÄGG TILL ANVÄNDARE",fontFamily=FontFamily.Serif,fontWeight=FontWeight.Black,color=p.text)},text={Column{RetroField(name,{name=it},"Namn",Modifier.fillMaxWidth(),p);Spacer(Modifier.height(12.dp));userColors.chunked(4).forEach{row->Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){row.forEach{c->Box(Modifier.size(42.dp).clip(CircleShape).background(Color(c)).border(if(c==color)4.dp else 1.dp,if(c==color)p.text else p.outline,CircleShape).clickable{color=c})}};Spacer(Modifier.height(7.dp))};if(error.isNotBlank())Text(error,color=p.red)}},confirmButton={RetroButton("SPARA",{val n=capitalized(name);error=when{n.isBlank()->"Skriv ett namn";users.any{it.name.equals(n,true)}->"Namnet finns redan";else->""};if(error.isBlank())onAdd(n,color)},p)},dismissButton={RetroButton("AVBRYT",onDismiss,p,danger=true)})}

enum class StatsPeriod(val label:String,val days:Int?){WEEK("1 VECKA",7),MONTH("1 MÅNAD",30),YEAR("1 ÅR",365),LIFETIME("LIVSTID",null)}
@Composable private fun StatsScreen(lists:List<ShoppingListData>,events:List<StatEvent>,users:List<UserProfile>,p:Palette,onBack:()->Unit,onReset:()->Unit){
    var period by remember{mutableStateOf(StatsPeriod.MONTH)}
    var reset by remember{mutableStateOf(false)}
    var menu by remember{mutableStateOf(false)}
    val cutoff=period.days?.let{System.currentTimeMillis()-it*86400000L}
    val filtered=events.filter{cutoff==null||it.timestamp>=cutoff}
    val purchases=filtered.filter{it.kind=="purchase"}
    val topItems=purchases.groupingBy{it.itemName}.eachCount().entries.sortedByDescending{it.value}.take(5)
    val mostActive=users.maxByOrNull{u->purchases.count{it.userId==u.id}}
    val mostActiveCount=mostActive?.let{u->purchases.count{it.userId==u.id}}?:0
    val favoriteList=lists.maxByOrNull{it.items.size}
    val totalItems=lists.sumOf{it.items.size}
    val completedNow=lists.sumOf{l->l.items.count{it.completed}}
    Column(Modifier.fillMaxSize().padding(14.dp)){
        Row(verticalAlignment=Alignment.CenterVertically){
            PageBack(onBack,p);Spacer(Modifier.width(10.dp))
            Text("STATISTIK",fontFamily=FontFamily.Serif,fontWeight=FontWeight.Black,fontSize=25.sp,color=p.pageText,modifier=Modifier.weight(1f))
            Box{RetroButton(period.label,{menu=true},p,compact=true);DropdownMenu(menu,{menu=false}){StatsPeriod.entries.forEach{x->DropdownMenuItem(text={Text(x.label)},onClick={period=x;menu=false})}}}
        }
        Spacer(Modifier.height(12.dp))
        LazyColumn(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(9.dp)){
            item{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(9.dp)){StatsCard("📋","SKAPADE LISTOR",lists.size.toString(),p,Modifier.weight(1f));StatsCard("🛒","TILLAGDA VAROR",totalItems.toString(),p,Modifier.weight(1f))}}
            item{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(9.dp)){StatsCard("✓","AVPRICKADE",completedNow.toString(),p,Modifier.weight(1f));StatsCard("★","UNDER PERIODEN",purchases.size.toString(),p,Modifier.weight(1f))}}
            item{FeatureStatCard("👤","MEST AKTIV ANVÄNDARE",if(mostActiveCount>0)"${mostActive?.name} – $mostActiveCount avprickningar" else "Ingen statistik ännu",p)}
            item{FeatureStatCard("🏆","MEST ANVÄNDA LISTA",favoriteList?.let{"${it.name} – ${it.items.size} varor"}?:"Ingen lista ännu",p)}
            item{Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(p.paper).border(2.dp,p.outline,RoundedCornerShape(10.dp)).padding(14.dp)){
                Text("MEST HANDLADE",fontFamily=FontFamily.Serif,fontWeight=FontWeight.Black,color=p.text)
                Spacer(Modifier.height(6.dp))
                if(topItems.isEmpty())Text("Ingen statistik ännu",color=p.muted)
                topItems.forEachIndexed{i,x->Text("${i+1}. ${x.key}  ·  ${x.value}",fontWeight=FontWeight.Bold,color=p.text,modifier=Modifier.padding(vertical=3.dp))}
            }}
        }
        RetroButton("NOLLSTÄLL STATISTIK",{reset=true},p,danger=true,modifier=Modifier.fillMaxWidth())
    }
    if(reset)ConfirmDialog("Nollställ statistik?","Detta kan inte ångras. Listor och varor påverkas inte.",p,{reset=false},{onReset();reset=false},confirmLabel="NOLLSTÄLL")
}
@Composable private fun StatsCard(icon:String,title:String,value:String,p:Palette,modifier:Modifier=Modifier){Column(modifier.clip(RoundedCornerShape(10.dp)).background(p.paper).border(2.dp,p.outline,RoundedCornerShape(10.dp)).padding(14.dp),horizontalAlignment=Alignment.CenterHorizontally){Text(icon,fontSize=25.sp);Text(title,fontFamily=FontFamily.Serif,fontWeight=FontWeight.Black,fontSize=11.sp,color=p.text,textAlign=TextAlign.Center);Text(value,fontSize=30.sp,fontWeight=FontWeight.Black,color=p.green)}}
@Composable private fun FeatureStatCard(icon:String,title:String,value:String,p:Palette){Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(p.paper).border(2.dp,p.outline,RoundedCornerShape(10.dp)).padding(14.dp),verticalAlignment=Alignment.CenterVertically){Text(icon,fontSize=30.sp);Spacer(Modifier.width(12.dp));Column{Text(title,fontFamily=FontFamily.Serif,fontWeight=FontWeight.Black,fontSize=13.sp,color=p.text);Text(value,fontWeight=FontWeight.Bold,color=p.green)}}}

@Composable private fun AboutScreen(p:Palette,onBack:()->Unit){Column(Modifier.fillMaxSize().padding(14.dp)){PageHeader("OM",p,onBack);Spacer(Modifier.height(35.dp));Text("Bubbsun",fontFamily=FontFamily.Cursive,fontStyle=FontStyle.Italic,fontWeight=FontWeight.Black,fontSize=54.sp,color=Color(0xFFC94F32),modifier=Modifier.align(Alignment.CenterHorizontally));Text("DIN VARDAG. DINA LISTOR.",fontFamily=FontFamily.Serif,fontWeight=FontWeight.Black,color=p.gold,modifier=Modifier.align(Alignment.CenterHorizontally));Spacer(Modifier.height(24.dp));Text("Version 0.301",fontFamily=FontFamily.Serif,color=p.pageMuted,modifier=Modifier.align(Alignment.CenterHorizontally));HorizontalDivider(color=p.outline,modifier=Modifier.padding(vertical=20.dp));Text("Bubbsun hjälper dig att hålla ordning på det som är viktigt. Skapa listor, välj egna ikoner, flytta saker och bocka av dem – varje dag.",fontFamily=FontFamily.Serif,fontSize=18.sp,lineHeight=26.sp,color=p.pageText,textAlign=TextAlign.Center);Spacer(Modifier.weight(1f));Text("© 2026 Bubbsun",color=p.pageMuted,modifier=Modifier.align(Alignment.CenterHorizontally))}}

@Composable private fun PageHeader(title:String,p:Palette,onBack:()->Unit,trailing: (@Composable () -> Unit)? = null){Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){PageBack(onBack,p);Spacer(Modifier.width(10.dp));Text(title.uppercase(),fontFamily=FontFamily.Serif,fontWeight=FontWeight.Black,fontSize=24.sp,color=p.pageText,modifier=Modifier.weight(1f));trailing?.invoke()}}
@Composable private fun PageBack(onBack:()->Unit,p:Palette){
    Button(onClick=onBack,shape=RoundedCornerShape(9.dp),colors=ButtonDefaults.buttonColors(containerColor=p.panel),contentPadding=PaddingValues(0.dp),modifier=Modifier.size(58.dp).border(2.dp,p.outline,RoundedCornerShape(9.dp))){
        Canvas(Modifier.size(35.dp)){
            val c=Color(0xFFF1DEAC);val sw=4.5.dp.toPx()
            val y=size.height*.52f
            drawLine(c,androidx.compose.ui.geometry.Offset(size.width*.18f,y),androidx.compose.ui.geometry.Offset(size.width*.84f,y),sw,StrokeCap.Round)
            drawLine(c,androidx.compose.ui.geometry.Offset(size.width*.18f,y),androidx.compose.ui.geometry.Offset(size.width*.43f,size.height*.25f),sw,StrokeCap.Round)
            drawLine(c,androidx.compose.ui.geometry.Offset(size.width*.18f,y),androidx.compose.ui.geometry.Offset(size.width*.43f,size.height*.79f),sw,StrokeCap.Round)
            drawLine(c,androidx.compose.ui.geometry.Offset(size.width*.44f,size.height*.38f),androidx.compose.ui.geometry.Offset(size.width*.72f,size.height*.38f),sw*.55f,StrokeCap.Round)
        }
    }
}
@Composable private fun RetroTitle(text:String,p:Palette){Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(7.dp)).background(p.green).padding(9.dp),contentAlignment=Alignment.Center){Text(text,fontFamily=FontFamily.Serif,fontWeight=FontWeight.Black,fontSize=17.sp,color=Color(0xFFE8D7A8))}}
@Composable private fun DeleteButton(onClick:()->Unit,p:Palette){
    Button(onClick,shape=RoundedCornerShape(8.dp),colors=ButtonDefaults.buttonColors(containerColor=p.red,contentColor=Color(0xFFF6E8C3)),contentPadding=PaddingValues(0.dp),modifier=Modifier.size(50.dp)){
        Canvas(Modifier.size(27.dp)){
            val c=Color(0xFFF6E8C3);val sw=3.1.dp.toPx()
            drawLine(c,androidx.compose.ui.geometry.Offset(size.width*.25f,size.height*.28f),androidx.compose.ui.geometry.Offset(size.width*.75f,size.height*.28f),sw,StrokeCap.Round)
            drawLine(c,androidx.compose.ui.geometry.Offset(size.width*.40f,size.height*.18f),androidx.compose.ui.geometry.Offset(size.width*.60f,size.height*.18f),sw,StrokeCap.Round)
            val path=Path().apply{moveTo(size.width*.30f,size.height*.34f);lineTo(size.width*.35f,size.height*.82f);lineTo(size.width*.65f,size.height*.82f);lineTo(size.width*.70f,size.height*.34f)}
            drawPath(path,c,style=Stroke(width=sw,cap=StrokeCap.Round))
            drawLine(c,androidx.compose.ui.geometry.Offset(size.width*.43f,size.height*.43f),androidx.compose.ui.geometry.Offset(size.width*.45f,size.height*.72f),sw*.72f,StrokeCap.Round)
            drawLine(c,androidx.compose.ui.geometry.Offset(size.width*.57f,size.height*.43f),androidx.compose.ui.geometry.Offset(size.width*.55f,size.height*.72f),sw*.72f,StrokeCap.Round)
        }
    }
}
@Composable private fun SquareIcon(text:String,onClick:()->Unit,p:Palette,large:Boolean=false){Button(onClick,shape=RoundedCornerShape(8.dp),colors=ButtonDefaults.buttonColors(containerColor=p.panel,contentColor=Color(0xFFEAD7A8)),contentPadding=PaddingValues(0.dp),modifier=Modifier.size(if(large)56.dp else 44.dp).border(2.dp,p.outline,RoundedCornerShape(8.dp))){Text(text,fontSize=if(large)31.sp else 22.sp,fontWeight=FontWeight.Black)}}
@Composable private fun EditDialog(item:ShoppingItem,p:Palette,onDismiss:()->Unit,onSave:(String,String)->Unit){var n by remember{mutableStateOf(item.name)};var q by remember{mutableStateOf(item.quantity)};AlertDialog(onDismissRequest=onDismiss,containerColor=p.paper,title={Text("REDIGERA VARA",fontFamily=FontFamily.Serif,fontWeight=FontWeight.Black,color=p.text)},text={Column{RetroField(n,{n=it},"Vara",Modifier.fillMaxWidth(),p);Spacer(Modifier.height(9.dp));RetroField(q,{q=it},"Mängd/enhet, t.ex. 2 paket",Modifier.fillMaxWidth(),p)}},confirmButton={RetroButton("SPARA",{if(n.isNotBlank())onSave(n,q)},p)},dismissButton={RetroButton("AVBRYT",onDismiss,p,danger=true)})}
@Composable private fun ConfirmDialog(title:String,text:String,p:Palette,onDismiss:()->Unit,onConfirm:()->Unit,confirmLabel:String="BEKRÄFTA"){AlertDialog(onDismissRequest=onDismiss,containerColor=p.paper,title={Text(title,fontFamily=FontFamily.Serif,fontWeight=FontWeight.Black,color=p.text)},text={Text(text,color=p.text)},confirmButton={RetroButton(confirmLabel,onConfirm,p,danger=true)},dismissButton={RetroButton("AVBRYT",onDismiss,p)})}
@Composable private fun RetroField(value:String,onValueChange:(String)->Unit,placeholder:String,modifier:Modifier,p:Palette,onDone:()->Unit={}){OutlinedTextField(value,onValueChange,modifier=modifier,singleLine=true,placeholder={Text(placeholder,color=p.muted)},keyboardOptions=KeyboardOptions(capitalization=KeyboardCapitalization.Sentences,imeAction=ImeAction.Done),keyboardActions=KeyboardActions(onDone={onDone()}),shape=RoundedCornerShape(8.dp),colors=OutlinedTextFieldDefaults.colors(focusedTextColor=p.text,unfocusedTextColor=p.text,focusedBorderColor=p.gold,unfocusedBorderColor=p.outline,cursorColor=p.gold,focusedContainerColor=p.paper,unfocusedContainerColor=p.paper))}
@Composable private fun RetroButton(text:String,onClick:()->Unit,p:Palette,modifier:Modifier=Modifier,compact:Boolean=false,danger:Boolean=false){Button(onClick,modifier=modifier,shape=RoundedCornerShape(8.dp),colors=ButtonDefaults.buttonColors(containerColor=if(danger)p.red else p.green,contentColor=Color(0xFFF4E4BA)),contentPadding=PaddingValues(horizontal=if(compact)10.dp else 14.dp,vertical=if(compact)9.dp else 13.dp)){Text(text,fontFamily=FontFamily.Serif,fontWeight=FontWeight.Black,fontSize=if(compact)13.sp else 17.sp)}}
private fun capitalized(s:String)=s.trim().replaceFirstChar{if(it.isLowerCase())it.titlecase()else it.toString()}
