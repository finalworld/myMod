# Bubbsun v0.301 – Retro Edition

Bubbsun är en mobil listapp i tydlig retro/vintage-stil. Projektet är redo att läggas upp på GitHub och byggas via Android Studio eller GitHub Actions.

## Nytt i v0.301
- Färgmarkering och text visar vem som lagt till varje vara
- Mängd/enhet för varor, exempelvis `2 paket`, `1 kg` eller `3 liter`
- Endast en tydlig bockknapp för att lägga till vara
- Mörkare och tydligare kryssrutor i mörkt tema
- Ny tydlig retro-papperskorg med röd bakgrund
- Större och kraftigare tillbaka-pil
- Statistik i tydliga kort: listor, varor, avprickningar, mest aktiv användare och mest använda lista
- Svensk text: **Nollställ statistik** med tydlig bekräftelse
- Förbättrad kontrast och läsbarhet i mörkt tema
- 16 valbara listikoner och flera ikonfärger
- Flyttbara listor och varor med långtryck och vibration

## Bygga APK på GitHub
1. Skapa ett nytt GitHub-repository.
2. Ladda upp hela innehållet i ZIP-filen, inte själva ZIP-filen.
3. Öppna fliken **Actions**.
4. Kör arbetsflödet **Bygg Bubbsun APK**.
5. Hämta APK-filen under **Artifacts** när bygget är klart.

## Lokal byggning
Öppna projektmappen i Android Studio och bygg `app` som vanligt.
