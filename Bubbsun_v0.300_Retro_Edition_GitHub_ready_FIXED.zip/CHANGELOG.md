# Ändringslogg

## v0.300 – Retro Edition
- Återställd färgmarkering för användaren som lade till varan.
- Nytt fält för mängd och enhet.
- Borttagen extra knapp längst ned på varusidan.
- Tydligare kryssrutor i mörkt tema.
- Ny retro-papperskorg enligt valt alternativ 1.
- Kraftigare tillbaka-pil på undersidor.
- Ombyggd statistikvy med tydliga kort och svensk terminologi.
- "Reset statistik" ersatt med "Nollställ statistik".
- Versionsnummer uppdaterat till 0.300.
