# Bubbsun 0.330

- Låst textstorlek i appen.
- Permanent signering för framtida uppdateringar.
- Redigering av listnamn.
- Enhetliga produkt- och mängdikoner.
- Statistik öppnas på Livstid.
- Autoifyllning av tidigare varor.
- Listan scrollar till toppen efter tillägg.
- Listnamn max 40 tecken och max två rader.
- Nyinstallation skapar endast Matinköp.
- Hemligt Frasse-easter egg med gummiankor.
