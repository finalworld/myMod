# Bubbsun v0.201 – Retro Vintage Edition

Ny design och funktioner enligt den senaste Bubbsun-mockupen.

## Nytt
- Hamburgermeny med aktiv användare, användarhantering, statistik och Om
- Aktiv användare kan bytas direkt i menyn
- Renare startsida utan statistik- och användarknappar
- 16 valbara listikoner och flera ikonfärger
- Flyttbara listor och listobjekt med långtryck, vibration och markeringsglöd
- Större sol/måne och tillbaka-pilar
- Vit papperskorg på röd bakgrund
- Senast tillagda objekt hamnar överst
- Ny retro/vintage-design och Bubbsun-logga
- Ny Om-sida

Projektet byggs med Android Studio eller GitHub Actions.
