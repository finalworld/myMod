package se.bubbsun.app

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID
import kotlin.math.abs

data class UserProfile(
    val id: String = UUID.randomUUID().toString(),
    var name: String,
    var colorHex: Long
)

class ShoppingItem(
    val id: String = UUID.randomUUID().toString(),
    name: String,
    quantity: String = "",
    ownerId: String,
    completed: Boolean = false,
    val createdAt: Long = System.currentTimeMillis(),
    completedAt: Long? = null
) {
    var name by mutableStateOf(name)
    var quantity by mutableStateOf(quantity)
    var ownerId by mutableStateOf(ownerId)
    var completed by mutableStateOf(completed)
    var completedAt by mutableStateOf(completedAt)
}

class ShoppingListData(
    val id: String = UUID.randomUUID().toString(),
    name: String,
    items: List<ShoppingItem> = emptyList()
) {
    var name by mutableStateOf(name)
    val items = mutableStateListOf<ShoppingItem>().apply { addAll(items) }
}

data class StatEvent(
    val id: String = UUID.randomUUID().toString(),
    val kind: String,
    val itemName: String,
    val userId: String,
    val timestamp: Long = System.currentTimeMillis()
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { BubbsunApp(applicationContext) }
    }
}

private class BubbsunStore(context: Context) {
    private val prefs = context.getSharedPreferences("bubbsun_store", Context.MODE_PRIVATE)

    fun loadUsers(): MutableList<UserProfile> {
        val raw = prefs.getString("users_v010", null)
        if (raw == null) return mutableListOf(
            UserProfile("danne", "Danne", 0xFFFFC928),
            UserProfile("sanja", "Sanja", 0xFFFF5E8A)
        )
        return runCatching {
            val arr = JSONArray(raw)
            MutableList(arr.length()) { i ->
                val o = arr.getJSONObject(i)
                UserProfile(o.getString("id"), o.getString("name"), o.getLong("color"))
            }
        }.getOrElse { mutableListOf(UserProfile("danne", "Danne", 0xFFFFC928), UserProfile("sanja", "Sanja", 0xFFFF5E8A)) }
    }

    fun saveUsers(users: List<UserProfile>) {
        val arr = JSONArray()
        users.forEach { u -> arr.put(JSONObject().apply { put("id", u.id); put("name", u.name); put("color", u.colorHex) }) }
        prefs.edit().putString("users_v010", arr.toString()).apply()
    }

    fun loadLists(users: List<UserProfile>): MutableList<ShoppingListData> {
        val raw = prefs.getString("lists", null) ?: return mutableListOf(ShoppingListData(name = "Inköpslista"))
        val danneId = users.firstOrNull { it.name.equals("Danne", true) }?.id ?: users.first().id
        val sanjaId = users.firstOrNull { it.name.equals("Sanja", true) }?.id ?: users.first().id
        return runCatching {
            val arr = JSONArray(raw)
            MutableList(arr.length()) { i ->
                val obj = arr.getJSONObject(i)
                val loaded = mutableListOf<ShoppingItem>()
                val itemArr = obj.optJSONArray("items") ?: JSONArray()
                repeat(itemArr.length()) { j ->
                    val it = itemArr.getJSONObject(j)
                    val legacyOwner = it.optString("owner", "DANNE")
                    val ownerId = it.optString("ownerId", if (legacyOwner == "SANJA") sanjaId else danneId)
                    loaded += ShoppingItem(
                        id = it.optString("id", UUID.randomUUID().toString()),
                        name = it.optString("name", ""),
                        quantity = it.optString("quantity", ""),
                        ownerId = ownerId,
                        completed = it.optBoolean("completed", false),
                        createdAt = it.optLong("createdAt", System.currentTimeMillis()),
                        completedAt = if (it.isNull("completedAt")) null else it.optLong("completedAt")
                    )
                }
                ShoppingListData(obj.optString("id", UUID.randomUUID().toString()), obj.optString("name", "Lista"), loaded)
            }
        }.getOrElse { mutableListOf(ShoppingListData(name = "Inköpslista")) }
    }

    fun saveLists(lists: List<ShoppingListData>) {
        val arr = JSONArray()
        lists.forEach { list ->
            val itemArr = JSONArray()
            list.items.forEach { item -> itemArr.put(JSONObject().apply {
                put("id", item.id); put("name", item.name); put("quantity", item.quantity); put("ownerId", item.ownerId)
                put("completed", item.completed); put("createdAt", item.createdAt); put("completedAt", item.completedAt ?: JSONObject.NULL)
            }) }
            arr.put(JSONObject().apply { put("id", list.id); put("name", list.name); put("items", itemArr) })
        }
        prefs.edit().putString("lists", arr.toString()).apply()
    }

    fun loadEvents(): MutableList<StatEvent> {
        val raw = prefs.getString("events_v010", null) ?: return mutableListOf()
        return runCatching {
            val arr = JSONArray(raw)
            MutableList(arr.length()) { i -> val o=arr.getJSONObject(i); StatEvent(o.getString("id"),o.getString("kind"),o.getString("itemName"),o.optString("userId",""),o.getLong("timestamp")) }
        }.getOrElse { mutableListOf() }
    }
    fun saveEvents(events: List<StatEvent>) {
        val arr=JSONArray(); events.forEach { e -> arr.put(JSONObject().apply { put("id",e.id);put("kind",e.kind);put("itemName",e.itemName);put("userId",e.userId);put("timestamp",e.timestamp) }) }
        prefs.edit().putString("events_v010",arr.toString()).apply()
    }
    fun loadDark() = prefs.getBoolean("dark", false)
    fun saveDark(v:Boolean)=prefs.edit().putBoolean("dark",v).apply()
    fun loadUserId(defaultId:String)=prefs.getString("active_user_v010",defaultId) ?: defaultId
    fun saveUserId(id:String)=prefs.edit().putString("active_user_v010",id).apply()
}

data class Palette(val bg:Color,val header:Color,val card:Color,val paper:Color,val paper2:Color,val text:Color,val muted:Color,val accent:Color,val green:Color,val red:Color,val outline:Color)
private val lightPalette=Palette(Color(0xFFE8D7A8),Color(0xFF075B5A),Color(0xFFF1E5BD),Color(0xFFFFF3CF),Color(0xFFF5E5B5),Color(0xFF241C16),Color(0xFF675849),Color(0xFFFFBE22),Color(0xFF287B4D),Color(0xFFB83A2D),Color(0xFF7C5A26))
private val darkPalette=Palette(Color(0xFF181816),Color(0xFF064C4A),Color(0xFF2A261F),Color(0xFF393128),Color(0xFF453A2E),Color(0xFFFFF0C8),Color(0xFFD4C4A1),Color(0xFFFFBE22),Color(0xFF3A8C58),Color(0xFFC84D3E),Color(0xFF9C7A3D))
private val userColors=listOf(0xFFFFC928,0xFFFF5E8A,0xFFFF8A2B,0xFFE84B3C,0xFF9E3F45,0xFF7846A8,0xFF3487C7,0xFF35AFC2,0xFF3BA78F,0xFF7BAD43,0xFFB4D936,0xFF8A5B35,0xFFD8B98A,0xFF244F73,0xFF9DD8B7,0xFF777777)

@Composable
fun BubbsunApp(context: Context) {
    val store=remember{BubbsunStore(context)}
    val users=remember{mutableStateListOf<UserProfile>().apply{addAll(store.loadUsers())}}
    val lists=remember{mutableStateListOf<ShoppingListData>().apply{addAll(store.loadLists(users))}}
    val events=remember{mutableStateListOf<StatEvent>().apply{addAll(store.loadEvents())}}
    var activeUserId by remember{mutableStateOf(store.loadUserId(users.first().id))}
    var dark by remember{mutableStateOf(store.loadDark())}
    var screen by remember{mutableStateOf("lists")}
    var selectedListId by remember{mutableStateOf<String?>(null)}
    val palette=if(dark) darkPalette else lightPalette

    BackHandler(enabled=screen!="lists") { screen="lists"; selectedListId=null }

    MaterialTheme(colorScheme=if(dark) darkColorScheme(background=palette.bg,surface=palette.paper,onSurface=palette.text,primary=palette.accent) else lightColorScheme(background=palette.bg,surface=palette.paper,onSurface=palette.text,primary=palette.accent)) {
        Surface(Modifier.fillMaxSize(),color=palette.bg) {
            Column(Modifier.fillMaxSize().safeDrawingPadding()) {
                Header(users,activeUserId,dark,palette,
                    onUser={activeUserId=it;store.saveUserId(it)},
                    onTheme={dark=!dark;store.saveDark(dark)})
                when(screen){
                    "lists"->ListsScreen(lists,users,palette,
                        onOpen={selectedListId=it;screen="list"},onStats={screen="stats"},
                        onUsers={screen="users"},onSave={store.saveLists(lists)})
                    "stats"->StatsScreen(lists,events,users,palette,onBack={screen="lists"},onReset={events.clear();store.saveEvents(events)})
                    "users"->UsersScreen(users,activeUserId,palette,onBack={screen="lists"},onSave={
                        if(users.none{it.id==activeUserId}) activeUserId=users.first().id
                        store.saveUsers(users);store.saveUserId(activeUserId)
                    })
                    else->{
                        val list=lists.firstOrNull{it.id==selectedListId}
                        if(list==null){screen="lists"} else ShoppingListScreen(list,users,activeUserId,palette,onBack={screen="lists"},onSave={store.saveLists(lists)},onEvent={events.add(it);store.saveEvents(events)})
                    }
                }
            }
        }
    }
}

@Composable private fun Header(users:List<UserProfile>,activeId:String,dark:Boolean,p:Palette,onUser:(String)->Unit,onTheme:()->Unit){
    val active=users.firstOrNull{it.id==activeId}?:users.first()
    Row(Modifier.fillMaxWidth().background(p.header).padding(12.dp),verticalAlignment=Alignment.CenterVertically){
        Text("BUBBSUN",fontFamily=FontFamily.Serif,fontWeight=FontWeight.Black,fontSize=30.sp,color=p.accent)
        Spacer(Modifier.weight(1f))
        var open by remember{mutableStateOf(false)}
        Box{
            RetroButton("● ${active.name.uppercase()}",{open=true},p,compact=true,container=Color(active.colorHex))
            DropdownMenu(open,{open=false}) { users.forEach{u->DropdownMenuItem(text={Text(u.name)},onClick={onUser(u.id);open=false},leadingIcon={Box(Modifier.size(14.dp).clip(RoundedCornerShape(50)).background(Color(u.colorHex)))})} }
        }
        Spacer(Modifier.width(8.dp));RetroButton(if(dark)"☀" else "☾",onTheme,p,compact=true)
    }
}

@Composable private fun ListsScreen(lists:SnapshotStateList<ShoppingListData>,users:List<UserProfile>,p:Palette,onOpen:(String)->Unit,onStats:()->Unit,onUsers:()->Unit,onSave:()->Unit){
    var add by remember{mutableStateOf(false)};var name by remember{mutableStateOf("")};var deleteTarget by remember{mutableStateOf<ShoppingListData?>(null)}
    Column(Modifier.fillMaxSize().padding(14.dp)){
        Row(verticalAlignment=Alignment.CenterVertically){Text("MINA LISTOR",fontFamily=FontFamily.Serif,fontWeight=FontWeight.Black,fontSize=25.sp,color=p.text);Spacer(Modifier.weight(1f));RetroButton("👥",onUsers,p,compact=true);Spacer(Modifier.width(6.dp));RetroButton("STATISTIK",onStats,p,compact=true)}
        Spacer(Modifier.height(12.dp))
        LazyColumn(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(9.dp)){
            items(lists,key={it.id}){l->
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(13.dp)).background(p.paper).border(2.dp,p.outline,RoundedCornerShape(13.dp)).clickable{onOpen(l.id)}.padding(15.dp),verticalAlignment=Alignment.CenterVertically){
                    Column(Modifier.weight(1f)){Text(l.name,fontWeight=FontWeight.Black,fontSize=21.sp,color=p.text);Text("${l.items.count{!it.completed}} att köpa • ${l.items.count{it.completed}} klart",color=p.muted)}
                    RetroButton("🗑",{deleteTarget=l},p,compact=true,danger=true)
                }
            }
        }
        if(add) Row(verticalAlignment=Alignment.CenterVertically){RetroField(name,{name=it},"Listnamn",Modifier.weight(1f),p);Spacer(Modifier.width(8.dp));RetroButton("SPARA",{val n=capitalized(name);if(n.isNotBlank()){lists.add(ShoppingListData(name=n));name="";add=false;onSave()}},p)} else RetroButton("+ NY LISTA",{add=true},p,modifier=Modifier.fillMaxWidth())
    }
    deleteTarget?.let{l->ConfirmDialog("Ta bort listan \"${l.name}\"?","Alla saker i listan försvinner.",p,{deleteTarget=null},{lists.remove(l);deleteTarget=null;onSave()})}
}

@Composable private fun UsersScreen(users:SnapshotStateList<UserProfile>,activeId:String,p:Palette,onBack:()->Unit,onSave:()->Unit){
    var showAdd by remember{mutableStateOf(false)};var deleteTarget by remember{mutableStateOf<UserProfile?>(null)}
    Column(Modifier.fillMaxSize().padding(14.dp)){
        Row(verticalAlignment=Alignment.CenterVertically){RetroButton("←",onBack,p,compact=true);Spacer(Modifier.width(10.dp));Text("ANVÄNDARE",fontFamily=FontFamily.Serif,fontWeight=FontWeight.Black,fontSize=25.sp,color=p.text)}
        Spacer(Modifier.height(12.dp))
        LazyColumn(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(9.dp)){items(users,key={it.id}){u->Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(13.dp)).background(p.paper).border(2.dp,p.outline,RoundedCornerShape(13.dp)).padding(14.dp),verticalAlignment=Alignment.CenterVertically){Box(Modifier.size(26.dp).clip(RoundedCornerShape(50)).background(Color(u.colorHex)));Spacer(Modifier.width(12.dp));Text(u.name,fontWeight=FontWeight.Black,fontSize=20.sp,color=p.text,modifier=Modifier.weight(1f));if(users.size>1) RetroButton("🗑",{deleteTarget=u},p,compact=true,danger=true)}}}
        RetroButton("+ LÄGG TILL ANVÄNDARE",{showAdd=true},p,modifier=Modifier.fillMaxWidth())
    }
    if(showAdd) AddUserDialog(users,p,{showAdd=false},{n,c->users.add(UserProfile(name=capitalized(n),colorHex=c));showAdd=false;onSave()})
    deleteTarget?.let{u->ConfirmDialog("Ta bort ${u.name}?","Varor som redan lagts till behåller sin färg tills de ändras.",p,{deleteTarget=null},{users.remove(u);deleteTarget=null;onSave()})}
}

@Composable private fun AddUserDialog(users:List<UserProfile>,p:Palette,onDismiss:()->Unit,onAdd:(String,Long)->Unit){
    var name by remember{mutableStateOf("")};var color by remember{mutableStateOf(userColors.first())};var error by remember{mutableStateOf("")}
    AlertDialog(onDismissRequest=onDismiss,containerColor=p.paper,title={Text("LÄGG TILL ANVÄNDARE",fontFamily=FontFamily.Serif,fontWeight=FontWeight.Black,color=p.text)},text={Column{RetroField(name,{name=it},"Namn",Modifier.fillMaxWidth(),p);Spacer(Modifier.height(12.dp));Text("VÄLJ FÄRG",fontWeight=FontWeight.Black,color=p.text);Spacer(Modifier.height(8.dp));userColors.chunked(4).forEach{row->Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){row.forEach{c->Box(Modifier.size(44.dp).clip(RoundedCornerShape(50)).background(Color(c)).border(if(c==color)4.dp else 1.dp,if(c==color)p.text,p.outline,RoundedCornerShape(50)).clickable{color=c})}};Spacer(Modifier.height(7.dp))};if(error.isNotBlank())Text(error,color=p.red)}},confirmButton={RetroButton("SPARA",{val n=capitalized(name);error=when{n.isBlank()->"Skriv ett namn";users.any{it.name.equals(n,true)}->"Namnet finns redan";else->""};if(error.isBlank())onAdd(n,color)},p)},dismissButton={RetroButton("AVBRYT",onDismiss,p,danger=true)})
}

@Composable private fun ShoppingListScreen(list:ShoppingListData,users:List<UserProfile>,activeUserId:String,p:Palette,onBack:()->Unit,onSave:()->Unit,onEvent:(StatEvent)->Unit){
    var input by remember{mutableStateOf("")};var quantity by remember{mutableStateOf("")};var showDone by remember{mutableStateOf(true)};var editing by remember{mutableStateOf<ShoppingItem?>(null)}
    var deleteMode by remember{mutableStateOf(false)};val selected=remember{mutableStateListOf<String>()};var confirmDelete by remember{mutableStateOf(false)}
    val active=list.items.filter{!it.completed};val done=list.items.filter{it.completed}.sortedByDescending{it.completedAt?:0L}
    val suggestions=if(input.trim().length>=2) list.items.filter{it.name.contains(input.trim(),true)}.distinctBy{it.name.lowercase()}.take(5) else emptyList()
    fun save(){onSave()}
    fun addItem(raw:String,qty:String){val n=capitalized(raw);if(n.isBlank())return;val existing=list.items.firstOrNull{it.name.equals(n,true)};when{existing==null->list.items.add(0,ShoppingItem(name=n,quantity=qty.trim(),ownerId=activeUserId));existing.completed->{existing.completed=false;existing.completedAt=null;existing.ownerId=activeUserId;if(qty.isNotBlank())existing.quantity=qty.trim();list.items.remove(existing);list.items.add(0,existing)};else->{if(qty.isNotBlank())existing.quantity=qty.trim();list.items.remove(existing);list.items.add(0,existing)}};input="";quantity="";save()}
    Column(Modifier.fillMaxSize().imePadding().padding(horizontal=14.dp,vertical=10.dp)){
        Row(verticalAlignment=Alignment.CenterVertically){RetroButton("←",onBack,p,compact=true);Spacer(Modifier.width(10.dp));Text(list.name.uppercase(),fontFamily=FontFamily.Serif,fontWeight=FontWeight.Black,fontSize=25.sp,color=p.text,modifier=Modifier.weight(1f));RetroButton("🗑",{if(deleteMode){if(selected.isEmpty()){deleteMode=false}else confirmDelete=true}else deleteMode=true},p,compact=true,danger=true)}
        Spacer(Modifier.height(10.dp))
        Box{Column{RetroField(input,{input=it},"Vad behövs?",Modifier.fillMaxWidth(),p,onDone={addItem(input,quantity)});if(suggestions.isNotEmpty()){Card(Modifier.fillMaxWidth().padding(top=4.dp),shape=RoundedCornerShape(10.dp),colors=CardDefaults.cardColors(containerColor=p.paper),border=CardDefaults.outlinedCardBorder()){suggestions.forEach{s->Row(Modifier.fillMaxWidth().clickable{input=s.name;quantity=s.quantity}.padding(11.dp),verticalAlignment=Alignment.CenterVertically){Text("↩",color=p.accent);Spacer(Modifier.width(8.dp));Text(s.name+(if(s.quantity.isNotBlank())" • ${s.quantity}" else ""),color=p.text,fontWeight=FontWeight.Bold)}}}}}}
        Spacer(Modifier.height(8.dp));Row{RetroField(quantity,{quantity=it},"Mängd (valfritt)",Modifier.weight(1f),p,onDone={addItem(input,quantity)});Spacer(Modifier.width(8.dp));RetroButton("+ LÄGG TILL",{addItem(input,quantity)},p)}
        Spacer(Modifier.height(10.dp))
        Row(verticalAlignment=Alignment.CenterVertically){Text("ATT KÖPA • ${active.size}",fontFamily=FontFamily.Serif,fontWeight=FontWeight.Black,fontSize=18.sp,color=p.text,modifier=Modifier.weight(1f));if(deleteMode){Checkbox(selected.size==list.items.size && list.items.isNotEmpty(),{checked->selected.clear();if(checked)selected.addAll(list.items.map{it.id})});Text("MARKERA ALLA",fontWeight=FontWeight.Bold,color=p.text)}}
        LazyColumn(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(7.dp)){
            items(active,key={it.id}){item->ItemRow(item,users,p,deleteMode,selected.contains(item.id),onSelect={if(selected.contains(item.id))selected.remove(item.id)else selected.add(item.id)},onToggle={item.completed=true;item.completedAt=System.currentTimeMillis();onEvent(StatEvent(kind="purchase",itemName=item.name,userId=item.ownerId));save()},onEdit={editing=item},onMove={dir->val current=list.items.filter{!it.completed};val from=current.indexOfFirst{it.id==item.id};val to=(from+dir).coerceIn(0,current.lastIndex);if(from>=0&&from!=to){val other=current[to];val a=list.items.indexOf(item);val b=list.items.indexOf(other);list.items[a]=other;list.items[b]=item;save()}})}
            item{Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(p.green).clickable{showDone=!showDone}.padding(11.dp)){Text(if(showDone)"KLART (${done.size})  ▲" else "KLART (${done.size})  ▼",fontFamily=FontFamily.Serif,fontWeight=FontWeight.Black,color=Color.White)}}
            if(showDone)items(done,key={"d${it.id}"}){item->ItemRow(item,users,p,deleteMode,selected.contains(item.id),onSelect={if(selected.contains(item.id))selected.remove(item.id)else selected.add(item.id)},onToggle={item.completed=false;item.completedAt=null;list.items.remove(item);list.items.add(0,item);save()},onEdit={editing=item},onMove={})}
        }
    }
    editing?.let{i->EditDialog(i,p,{editing=null},{n,q->i.name=capitalized(n);i.quantity=q.trim();editing=null;save()})}
    if(confirmDelete)ConfirmDialog("Ta bort ${selected.size} markerade saker?","Det går inte att ångra.",p,{confirmDelete=false},{val doomed=list.items.filter{selected.contains(it.id)};doomed.forEach{onEvent(StatEvent(kind="delete",itemName=it.name,userId=it.ownerId))};list.items.removeAll(doomed);selected.clear();deleteMode=false;confirmDelete=false;save()})
}

@Composable private fun ItemRow(item:ShoppingItem,users:List<UserProfile>,p:Palette,deleteMode:Boolean,isSelected:Boolean,onSelect:()->Unit,onToggle:()->Unit,onEdit:()->Unit,onMove:(Int)->Unit){
    var drag by remember{mutableStateOf(0f)};val user=users.firstOrNull{it.id==item.ownerId};val strip=Color(user?.colorHex?:0xFF777777)
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(p.paper).border(2.dp,p.outline,RoundedCornerShape(12.dp)),verticalAlignment=Alignment.CenterVertically){
        Box(Modifier.width(9.dp).height(68.dp).background(strip));Checkbox(item.completed,{onToggle()});Column(Modifier.weight(1f).padding(vertical=8.dp)){Text(item.name,fontWeight=FontWeight.Black,fontSize=20.sp,color=p.text,textDecoration=if(item.completed)TextDecoration.LineThrough else null);if(item.quantity.isNotBlank())Text(item.quantity,color=p.muted);if(item.completed&&user!=null)Text(user.name,color=strip,fontSize=12.sp)}
        if(deleteMode)Checkbox(isSelected,{onSelect()}) else {if(!item.completed)Text("≡",fontSize=28.sp,color=p.muted,modifier=Modifier.padding(10.dp).pointerInput(item.id){detectDragGesturesAfterLongPress(onDragStart={drag=0f},onDragEnd={drag=0f},onDragCancel={drag=0f},onDrag={change,amount->change.consume();drag+=amount.y;if(abs(drag)>42f){onMove(if(drag>0)1 else -1);drag=0f}})});Text("✎",fontSize=22.sp,color=p.muted,modifier=Modifier.clickable{onEdit()}.padding(12.dp))}
    }
}

enum class StatsPeriod(val label:String,val days:Int?){WEEK("1 VECKA",7),MONTH("1 MÅNAD",30),YEAR("1 ÅR",365),LIFETIME("LIVSTID",null)}
@Composable private fun StatsScreen(lists:List<ShoppingListData>,events:List<StatEvent>,users:List<UserProfile>,p:Palette,onBack:()->Unit,onReset:()->Unit){
    var period by remember{mutableStateOf(StatsPeriod.MONTH)};var reset by remember{mutableStateOf(false)};var menu by remember{mutableStateOf(false)}
    val cutoff=period.days?.let{System.currentTimeMillis()-it*86400000L};val e=events.filter{cutoff==null||it.timestamp>=cutoff};val purchases=e.filter{it.kind=="purchase"};val deletes=e.filter{it.kind=="delete"};val top=purchases.groupingBy{it.itemName}.eachCount().entries.sortedByDescending{it.value}.take(5)
    Column(Modifier.fillMaxSize().padding(14.dp)){Row(verticalAlignment=Alignment.CenterVertically){RetroButton("←",onBack,p,compact=true);Spacer(Modifier.width(10.dp));Text("STATISTIK",fontFamily=FontFamily.Serif,fontWeight=FontWeight.Black,fontSize=25.sp,color=p.text,modifier=Modifier.weight(1f));Box{RetroButton(period.label,{menu=true},p,compact=true);DropdownMenu(menu,{menu=false}){StatsPeriod.entries.forEach{x->DropdownMenuItem(text={Text(x.label)},onClick={period=x;menu=false})}}}}
        Spacer(Modifier.height(12.dp));LazyColumn(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(9.dp)){item{StatsCard("KLARA SAKER",purchases.size.toString(),p)};item{StatsCard("BORTTAGNA",deletes.size.toString(),p)};item{StatsCard("AKTIVA NU",lists.sumOf{l->l.items.count{!it.completed}}.toString(),p)};item{Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(p.paper).border(2.dp,p.outline,RoundedCornerShape(12.dp)).padding(14.dp)){Text("MEST HANDLADE",fontFamily=FontFamily.Serif,fontWeight=FontWeight.Black,color=p.text);if(top.isEmpty())Text("Ingen statistik ännu",color=p.muted);top.forEachIndexed{i,x->Text("${i+1}. ${x.key}  ${x.value}",fontWeight=FontWeight.Bold,color=p.text)}}};item{users.forEach{u->val count=purchases.count{it.userId==u.id};if(count>0)Text("${u.name}: $count avbockningar",color=Color(u.colorHex),fontWeight=FontWeight.Bold)}}}
        RetroButton("RESET STATISTIK",{reset=true},p,danger=true,modifier=Modifier.fillMaxWidth())
    }
    if(reset)ConfirmDialog("Nollställ all statistik?","Listor och varor påverkas inte.",p,{reset=false},{onReset();reset=false})
}
@Composable private fun StatsCard(title:String,value:String,p:Palette){Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(p.paper).border(2.dp,p.outline,RoundedCornerShape(12.dp)).padding(16.dp)){Text(title,fontFamily=FontFamily.Serif,fontWeight=FontWeight.Black,color=p.text);Text(value,fontSize=30.sp,fontWeight=FontWeight.Black,color=p.green)}}

@Composable private fun EditDialog(item:ShoppingItem,p:Palette,onDismiss:()->Unit,onSave:(String,String)->Unit){var n by remember{mutableStateOf(item.name)};var q by remember{mutableStateOf(item.quantity)};AlertDialog(onDismissRequest=onDismiss,containerColor=p.paper,title={Text("REDIGERA",fontFamily=FontFamily.Serif,fontWeight=FontWeight.Black,color=p.text)},text={Column{RetroField(n,{n=it},"Vara",Modifier.fillMaxWidth(),p);Spacer(Modifier.height(8.dp));RetroField(q,{q=it},"Mängd",Modifier.fillMaxWidth(),p)}},confirmButton={RetroButton("SPARA",{if(n.isNotBlank())onSave(n,q)},p)},dismissButton={RetroButton("AVBRYT",onDismiss,p,danger=true)})}
@Composable private fun ConfirmDialog(title:String,text:String,p:Palette,onDismiss:()->Unit,onConfirm:()->Unit){AlertDialog(onDismissRequest=onDismiss,containerColor=p.paper,title={Text(title,fontFamily=FontFamily.Serif,fontWeight=FontWeight.Black,color=p.text)},text={Text(text,color=p.text)},confirmButton={RetroButton("BEKRÄFTA",onConfirm,p,danger=true)},dismissButton={RetroButton("AVBRYT",onDismiss,p)})}

@Composable private fun RetroField(value:String,onValueChange:(String)->Unit,placeholder:String,modifier:Modifier,p:Palette,onDone:()->Unit={}){OutlinedTextField(value,onValueChange,modifier=modifier,singleLine=true,placeholder={Text(placeholder,color=p.muted)},keyboardOptions=KeyboardOptions(capitalization=KeyboardCapitalization.Sentences,imeAction=ImeAction.Done),keyboardActions=KeyboardActions(onDone={onDone()}),shape=RoundedCornerShape(12.dp),colors=OutlinedTextFieldDefaults.colors(focusedTextColor=p.text,unfocusedTextColor=p.text,focusedBorderColor=p.accent,unfocusedBorderColor=p.outline,cursorColor=p.accent,focusedContainerColor=p.paper,unfocusedContainerColor=p.paper))}
@Composable private fun RetroButton(text:String,onClick:()->Unit,p:Palette,modifier:Modifier=Modifier,compact:Boolean=false,danger:Boolean=false,container:Color?=null){Button(onClick,modifier=modifier,shape=RoundedCornerShape(10.dp),colors=ButtonDefaults.buttonColors(containerColor=container?:if(danger)p.red else p.header,contentColor=if(container!=null&&container.luminance()>0.55f)Color.Black else Color.White),contentPadding=PaddingValues(horizontal=if(compact)11.dp else 15.dp,vertical=if(compact)8.dp else 11.dp)){Text(text,fontFamily=FontFamily.Serif,fontWeight=FontWeight.Black,fontSize=if(compact)14.sp else 16.sp)}}
private fun capitalized(s:String)=s.trim().replaceFirstChar{if(it.isLowerCase())it.titlecase() else it.toString()}
