# Ändringslogg
## v0.321

- Korrigerad variant 6 på sidan för att lägga till varor.
- Tog bort dekorationspunkterna runt fältetiketterna.
- Gjorde vara- och mängdfälten lika höga.
- Breddade mängdfältet och tog bort punkterna efter platshållarorden.
- Uppdaterade versionsnumret till 0.321.


## v0.320
- Lägg till vara-raden har fått designen från Idé 5 – Variant F (variant 6).
- Dekorativa retroetiketter för VARA och MÄNGD/ENHET har lagts till.
- Ingen funktionalitet eller annan design har ändrats.
- Versionsnummer uppdaterat till 0.320.


## v0.301
- Skapa lista-knappen är alltid synlig och fungerar efter att ett namn skrivits.
- "Markera alla" är tillbaka i papperskorgsläget.
- Användarens färgremsa ligger längst till vänster på varje vara.
- Texten "Tillagd av" är borttagen helt.
- Mängd/enhet-fältet är mindre och visar "Valfri…".
- Global kontrastfix för mörkt tema på rubriker och sidtexter.
- Ny kraftigare, handritad retropil på alla undersidor.
- Aktiv användares prick visar rätt användarfärg.
- Versionsnummer uppdaterat till 0.301.
