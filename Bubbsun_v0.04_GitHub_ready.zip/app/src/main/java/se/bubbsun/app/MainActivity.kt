package se.bubbsun.app

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID
import kotlin.math.abs

enum class Owner { DANNE, SANJA }

data class ShoppingItem(
    val id: String = UUID.randomUUID().toString(),
    var name: String,
    var quantity: String = "",
    var owner: Owner = Owner.DANNE,
    var completed: Boolean = false,
    var createdAt: Long = System.currentTimeMillis(),
    var completedAt: Long? = null,
    var purchaseCount: Int = 0,
    var removedCount: Int = 0
)

data class ShoppingListData(
    val id: String = UUID.randomUUID().toString(),
    var name: String,
    val items: MutableList<ShoppingItem> = mutableListOf()
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { BubbsunApp(applicationContext) }
    }
}

private class BubbsunStore(context: Context) {
    private val prefs = context.getSharedPreferences("bubbsun_store", Context.MODE_PRIVATE)

    fun loadLists(): MutableList<ShoppingListData> {
        val raw = prefs.getString("lists", null) ?: return mutableListOf(
            ShoppingListData(name = "Handla")
        )
        return runCatching {
            val arr = JSONArray(raw)
            MutableList(arr.length()) { i ->
                val obj = arr.getJSONObject(i)
                val itemArr = obj.optJSONArray("items") ?: JSONArray()
                val list = ShoppingListData(
                    id = obj.optString("id", UUID.randomUUID().toString()),
                    name = obj.optString("name", "Lista")
                )
                repeat(itemArr.length()) { j ->
                    val it = itemArr.getJSONObject(j)
                    list.items += ShoppingItem(
                        id = it.optString("id", UUID.randomUUID().toString()),
                        name = it.optString("name", ""),
                        quantity = it.optString("quantity", ""),
                        owner = runCatching { Owner.valueOf(it.optString("owner", "DANNE")) }.getOrDefault(Owner.DANNE),
                        completed = it.optBoolean("completed", false),
                        createdAt = it.optLong("createdAt", System.currentTimeMillis()),
                        completedAt = if (it.isNull("completedAt")) null else it.optLong("completedAt"),
                        purchaseCount = it.optInt("purchaseCount", 0),
                        removedCount = it.optInt("removedCount", 0)
                    )
                }
                list
            }
        }.getOrElse { mutableListOf(ShoppingListData(name = "Handla")) }
    }

    fun saveLists(lists: List<ShoppingListData>) {
        val arr = JSONArray()
        lists.forEach { list ->
            val itemArr = JSONArray()
            list.items.forEach { item ->
                itemArr.put(JSONObject().apply {
                    put("id", item.id)
                    put("name", item.name)
                    put("quantity", item.quantity)
                    put("owner", item.owner.name)
                    put("completed", item.completed)
                    put("createdAt", item.createdAt)
                    put("completedAt", item.completedAt ?: JSONObject.NULL)
                    put("purchaseCount", item.purchaseCount)
                    put("removedCount", item.removedCount)
                })
            }
            arr.put(JSONObject().apply {
                put("id", list.id)
                put("name", list.name)
                put("items", itemArr)
            })
        }
        prefs.edit().putString("lists", arr.toString()).apply()
    }

    fun loadDark() = prefs.getBoolean("dark", true)
    fun saveDark(value: Boolean) = prefs.edit().putBoolean("dark", value).apply()
    fun loadOwner() = runCatching { Owner.valueOf(prefs.getString("owner", "DANNE")!!) }.getOrDefault(Owner.DANNE)
    fun saveOwner(owner: Owner) = prefs.edit().putString("owner", owner.name).apply()
}

@Composable
fun BubbsunApp(context: Context) {
    val store = remember { BubbsunStore(context) }
    val lists = remember { mutableStateListOf<ShoppingListData>().apply { addAll(store.loadLists()) } }
    var selectedListId by remember { mutableStateOf<String?>(null) }
    var screen by remember { mutableStateOf("lists") }
    var dark by remember { mutableStateOf(store.loadDark()) }
    var owner by remember { mutableStateOf(store.loadOwner()) }

    val palette = if (dark) darkPalette else lightPalette

    MaterialTheme(
        colorScheme = if (dark) darkColorScheme(
            primary = palette.accent,
            secondary = palette.pink,
            background = palette.bg,
            surface = palette.card,
            onBackground = palette.text,
            onSurface = palette.text
        ) else lightColorScheme(
            primary = palette.accent,
            secondary = palette.pink,
            background = palette.bg,
            surface = palette.card,
            onBackground = palette.text,
            onSurface = palette.text
        )
    ) {
        Surface(Modifier.fillMaxSize(), color = palette.bg) {
            Column {
                BubbsunHeader(
                    dark = dark,
                    owner = owner,
                    onTheme = {
                        dark = !dark
                        store.saveDark(dark)
                    },
                    onOwner = {
                        owner = if (owner == Owner.DANNE) Owner.SANJA else Owner.DANNE
                        store.saveOwner(owner)
                    },
                    palette = palette
                )

                when (screen) {
                    "lists" -> ListsScreen(
                        lists = lists,
                        palette = palette,
                        onOpen = {
                            selectedListId = it
                            screen = "list"
                        },
                        onStats = { screen = "stats" },
                        onSave = { store.saveLists(lists) }
                    )
                    "stats" -> StatsScreen(
                        lists = lists,
                        palette = palette,
                        onBack = { screen = "lists" }
                    )
                    else -> {
                        val selected = lists.firstOrNull { it.id == selectedListId }
                        if (selected == null) {
                            screen = "lists"
                        } else {
                            ShoppingListScreen(
                                list = selected,
                                owner = owner,
                                palette = palette,
                                onBack = { screen = "lists" },
                                onSave = { store.saveLists(lists) }
                            )
                        }
                    }
                }
            }
        }
    }
}

data class Palette(
    val bg: Color,
    val card: Color,
    val card2: Color,
    val text: Color,
    val muted: Color,
    val accent: Color,
    val pink: Color,
    val red: Color,
    val green: Color
)

private val darkPalette = Palette(
    bg = Color(0xFF201C19),
    card = Color(0xFF302824),
    card2 = Color(0xFF3B312B),
    text = Color(0xFFFFF2CF),
    muted = Color(0xFFCCBFA6),
    accent = Color(0xFFFFC928),
    pink = Color(0xFFFF6FAE),
    red = Color(0xFFFF786B),
    green = Color(0xFF9BCB6B)
)
private val lightPalette = Palette(
    bg = Color(0xFFF4E2B8),
    card = Color(0xFFFFF1CB),
    card2 = Color(0xFFE8C88B),
    text = Color(0xFF35261D),
    muted = Color(0xFF765D4D),
    accent = Color(0xFFE6A700),
    pink = Color(0xFFE85B9A),
    red = Color(0xFFC94D3E),
    green = Color(0xFF658B3B)
)

@Composable
private fun BubbsunHeader(
    dark: Boolean,
    owner: Owner,
    onTheme: () -> Unit,
    onOwner: () -> Unit,
    palette: Palette
) {
    Row(
        Modifier
            .fillMaxWidth()
            .background(palette.card)
            .padding(horizontal = 14.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("BUBBSUN", fontSize = 26.sp, fontWeight = FontWeight.Black, color = palette.accent)
        Spacer(Modifier.weight(1f))
        RetroButton(
            text = if (owner == Owner.DANNE) "🟡 DANNE" else "🩷 SANJA",
            onClick = onOwner,
            palette = palette
        )
        Spacer(Modifier.width(8.dp))
        RetroButton(
            text = if (dark) "☀" else "☾",
            onClick = onTheme,
            palette = palette
        )
    }
}

@Composable
private fun ListsScreen(
    lists: SnapshotStateList<ShoppingListData>,
    palette: Palette,
    onOpen: (String) -> Unit,
    onStats: () -> Unit,
    onSave: () -> Unit
) {
    var showNew by remember { mutableStateOf(false) }
    var newName by remember { mutableStateOf("") }

    Column(Modifier.fillMaxSize().padding(14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("MINA LISTOR", fontSize = 24.sp, fontWeight = FontWeight.Black, color = palette.text)
            Spacer(Modifier.weight(1f))
            RetroButton("📊 STATISTIK", onStats, palette)
        }
        Spacer(Modifier.height(12.dp))

        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.weight(1f)) {
            items(lists, key = { it.id }) { list ->
                val active = list.items.count { !it.completed }
                val done = list.items.count { it.completed }
                Row(
                    Modifier
                        .fillMaxWidth()
                        .background(palette.card, RoundedCornerShape(18.dp))
                        .border(2.dp, palette.card2, RoundedCornerShape(18.dp))
                        .clickable { onOpen(list.id) }
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(list.name, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = palette.text)
                        Text("$active aktiva • $done klara", color = palette.muted)
                    }
                    if (lists.size > 1) {
                        RetroButton("🗑", {
                            lists.remove(list)
                            onSave()
                        }, palette, danger = true)
                    }
                }
            }
        }

        if (showNew) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                RetroField(
                    value = newName,
                    onValueChange = { newName = it },
                    placeholder = "Namn på listan",
                    modifier = Modifier.weight(1f),
                    palette = palette,
                    onDone = {
                        val n = newName.trim()
                        if (n.isNotEmpty()) {
                            lists.add(ShoppingListData(name = n))
                            newName = ""
                            showNew = false
                            onSave()
                        }
                    }
                )
                Spacer(Modifier.width(8.dp))
                RetroButton("SPARA", {
                    val n = newName.trim()
                    if (n.isNotEmpty()) {
                        lists.add(ShoppingListData(name = n))
                        newName = ""
                        showNew = false
                        onSave()
                    }
                }, palette)
            }
        } else {
            RetroButton("+ NY LISTA", { showNew = true }, palette, modifier = Modifier.fillMaxWidth())
        }
    }
}

@Composable
private fun ShoppingListScreen(
    list: ShoppingListData,
    owner: Owner,
    palette: Palette,
    onBack: () -> Unit,
    onSave: () -> Unit
) {
    var itemName by remember { mutableStateOf("") }
    var quantity by remember { mutableStateOf("") }
    var showDone by remember { mutableStateOf(true) }
    var editItem by remember { mutableStateOf<ShoppingItem?>(null) }

    val active = list.items.filter { !it.completed }
    val completed = list.items.filter { it.completed }.sortedByDescending { it.completedAt ?: 0L }
    val suggestions = remember(itemName, list.items.size) {
        if (itemName.trim().length < 2) emptyList()
        else list.items
            .filter { it.name.contains(itemName.trim(), ignoreCase = true) }
            .distinctBy { it.name.lowercase() }
            .take(4)
    }

    fun addOrRestore(nameRaw: String, qtyRaw: String) {
        val name = nameRaw.trim()
        val qty = qtyRaw.trim()
        if (name.isEmpty()) return
        val existing = list.items.firstOrNull { it.name.equals(name, ignoreCase = true) }
        when {
            existing == null -> list.items.add(0, ShoppingItem(name = name, quantity = qty, owner = owner))
            existing.completed -> {
                existing.completed = false
                existing.completedAt = null
                existing.quantity = qty.ifBlank { existing.quantity }
                existing.owner = owner
                list.items.remove(existing)
                list.items.add(0, existing)
            }
            else -> {
                existing.quantity = qty.ifBlank { existing.quantity }
                list.items.remove(existing)
                list.items.add(0, existing)
            }
        }
        itemName = ""
        quantity = ""
        onSave()
    }

    Column(Modifier.fillMaxSize().padding(14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            RetroButton("←", onBack, palette)
            Spacer(Modifier.width(10.dp))
            Text(list.name.uppercase(), fontSize = 24.sp, fontWeight = FontWeight.Black, color = palette.text)
        }
        Spacer(Modifier.height(12.dp))

        RetroField(
            value = itemName,
            onValueChange = { itemName = it },
            placeholder = "Vad behövs?",
            modifier = Modifier.fillMaxWidth(),
            palette = palette,
            onDone = { addOrRestore(itemName, quantity) }
        )
        Spacer(Modifier.height(8.dp))
        Row {
            RetroField(
                value = quantity,
                onValueChange = { quantity = it },
                placeholder = "Mängd (valfritt)",
                modifier = Modifier.weight(1f),
                palette = palette,
                onDone = { addOrRestore(itemName, quantity) }
            )
            Spacer(Modifier.width(8.dp))
            RetroButton("+ LÄGG TILL", { addOrRestore(itemName, quantity) }, palette)
        }

        suggestions.forEach { s ->
            Text(
                "↩ ${s.name}${if (s.quantity.isNotBlank()) " • ${s.quantity}" else ""}",
                color = palette.muted,
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { addOrRestore(s.name, s.quantity) }
                    .padding(8.dp)
            )
        }

        Spacer(Modifier.height(10.dp))
        Text("ATT KÖPA • ${active.size}", fontWeight = FontWeight.Black, color = palette.text)

        LazyColumn(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(active, key = { it.id }) { item ->
                ShoppingRow(
                    item = item,
                    palette = palette,
                    completed = false,
                    onToggle = {
                        item.completed = true
                        item.completedAt = System.currentTimeMillis()
                        item.purchaseCount += 1
                        onSave()
                    },
                    onEdit = { editItem = item },
                    onDelete = {
                        item.removedCount += 1
                        list.items.remove(item)
                        onSave()
                    },
                    onMove = { direction ->
                        val currentActive = list.items.filter { !it.completed }
                        val from = currentActive.indexOfFirst { it.id == item.id }
                        val to = (from + direction).coerceIn(0, currentActive.lastIndex)
                        if (from != to && from >= 0) {
                            val other = currentActive[to]
                            val idxA = list.items.indexOf(item)
                            val idxB = list.items.indexOf(other)
                            list.items[idxA] = other
                            list.items[idxB] = item
                            onSave()
                        }
                    }
                )
            }

            item {
                Spacer(Modifier.height(8.dp))
                Row(
                    Modifier
                        .fillMaxWidth()
                        .background(palette.card2, RoundedCornerShape(14.dp))
                        .clickable { showDone = !showDone }
                        .padding(12.dp)
                ) {
                    Text(if (showDone) "▼ KLART • ${completed.size}" else "▶ KLART • ${completed.size}",
                        fontWeight = FontWeight.Black, color = palette.text)
                }
            }

            if (showDone) {
                items(completed, key = { "done-${it.id}" }) { item ->
                    ShoppingRow(
                        item = item,
                        palette = palette,
                        completed = true,
                        onToggle = {
                            item.completed = false
                            item.completedAt = null
                            list.items.remove(item)
                            list.items.add(0, item)
                            onSave()
                        },
                        onEdit = { editItem = item },
                        onDelete = {
                            item.removedCount += 1
                            list.items.remove(item)
                            onSave()
                        },
                        onMove = {}
                    )
                }
            }
        }
    }

    editItem?.let { item ->
        EditDialog(
            item = item,
            palette = palette,
            onDismiss = { editItem = null },
            onSave = { n, q ->
                item.name = n
                item.quantity = q
                editItem = null
                onSave()
            }
        )
    }
}

@Composable
private fun ShoppingRow(
    item: ShoppingItem,
    palette: Palette,
    completed: Boolean,
    onToggle: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
    onMove: (Int) -> Unit
) {
    var dragTotal by remember { mutableStateOf(0f) }
    val ownerColor = if (item.owner == Owner.DANNE) palette.accent else palette.pink

    Row(
        Modifier
            .fillMaxWidth()
            .background(palette.card, RoundedCornerShape(16.dp))
            .border(2.dp, palette.card2, RoundedCornerShape(16.dp)),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.width(8.dp).height(64.dp).background(ownerColor))
        Checkbox(
            checked = completed,
            onCheckedChange = { onToggle() },
            colors = CheckboxDefaults.colors(checkedColor = palette.green)
        )
        Column(Modifier.weight(1f).padding(vertical = 8.dp)) {
            Text(
                item.name,
                fontSize = 19.sp,
                fontWeight = FontWeight.Bold,
                color = palette.text,
                textDecoration = if (completed) TextDecoration.LineThrough else null
            )
            if (item.quantity.isNotBlank()) Text(item.quantity, color = palette.muted)
        }
        if (!completed) {
            Text(
                "≡",
                fontSize = 28.sp,
                color = palette.muted,
                modifier = Modifier
                    .padding(horizontal = 8.dp)
                    .pointerInput(item.id) {
                        detectDragGesturesAfterLongPress(
                            onDragStart = { dragTotal = 0f },
                            onDragEnd = { dragTotal = 0f },
                            onDragCancel = { dragTotal = 0f },
                            onDrag = { change, amount ->
                                change.consume()
                                dragTotal += amount.y
                                if (abs(dragTotal) > 55f) {
                                    onMove(if (dragTotal > 0) 1 else -1)
                                    dragTotal = 0f
                                }
                            }
                        )
                    }
            )
        }
        Text("✎", fontSize = 22.sp, color = palette.muted,
            modifier = Modifier.clickable { onEdit() }.padding(10.dp))
        Text("🗑", fontSize = 19.sp,
            modifier = Modifier.clickable { onDelete() }.padding(10.dp))
    }
}

@Composable
private fun StatsScreen(
    lists: List<ShoppingListData>,
    palette: Palette,
    onBack: () -> Unit
) {
    var days by remember { mutableStateOf<Int?>(30) }
    val cutoff = days?.let { System.currentTimeMillis() - it * 86_400_000L }
    val allItems = lists.flatMap { it.items }
    val filteredPurchases = allItems.filter { item ->
        item.purchaseCount > 0 && (cutoff == null || (item.completedAt ?: item.createdAt) >= cutoff)
    }
    val purchases = filteredPurchases.sumOf { it.purchaseCount }
    val danne = allItems.count { it.owner == Owner.DANNE }
    val sanja = allItems.count { it.owner == Owner.SANJA }
    val totalOwners = (danne + sanja).coerceAtLeast(1)

    val mostBought = filteredPurchases.sortedByDescending { it.purchaseCount }.take(5)
    val mostRemoved = allItems.sortedByDescending { it.removedCount }.filter { it.removedCount > 0 }.take(5)

    Column(Modifier.fillMaxSize().padding(14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            RetroButton("←", onBack, palette)
            Spacer(Modifier.width(10.dp))
            Text("STATISTIK", fontSize = 24.sp, fontWeight = FontWeight.Black, color = palette.text)
        }
        Spacer(Modifier.height(12.dp))

        Row {
            RetroButton("30 DAGAR", { days = 30 }, palette, selected = days == 30, modifier = Modifier.weight(1f))
            Spacer(Modifier.width(8.dp))
            RetroButton("LIVSTID", { days = null }, palette, selected = days == null, modifier = Modifier.weight(1f))
        }

        Spacer(Modifier.height(12.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                StatsCard("🛒 AVBOCKADE", "$purchases varor", palette)
            }
            item {
                StatsCard(
                    "👥 VEM LADE TILL?",
                    "🟡 Danne ${(danne * 100 / totalOwners)} %   •   🩷 Sanja ${(sanja * 100 / totalOwners)} %",
                    palette
                )
            }
            item {
                StatsListCard("🏆 MEST KÖPTA", mostBought.map { "${it.name} – ${it.purchaseCount} ggr" }, palette)
            }
            item {
                StatsListCard("🗑 MEST BORTTAGNA", mostRemoved.map { "${it.name} – ${it.removedCount} ggr" }, palette)
            }
            item {
                val award = when {
                    mostBought.firstOrNull()?.name?.contains("kaffe", true) == true -> "☕ Kaffemonstret"
                    mostBought.firstOrNull()?.name?.contains("mjölk", true) == true -> "🥛 Mjölkkungen"
                    purchases >= 50 -> "🔥 Storhandlarna"
                    else -> "🌟 Bubbsun-början"
                }
                StatsCard("BUBBSUN AWARD", award, palette)
            }
            item {
                StatsCard(
                    "📦 NUVARANDE",
                    "${allItems.count { !it.completed }} aktiva • ${allItems.count { it.completed }} klara • ${allItems.size} totalt",
                    palette
                )
            }
        }
    }
}

@Composable
private fun StatsCard(title: String, value: String, palette: Palette) {
    Column(
        Modifier.fillMaxWidth()
            .background(palette.card, RoundedCornerShape(18.dp))
            .border(2.dp, palette.card2, RoundedCornerShape(18.dp))
            .padding(16.dp)
    ) {
        Text(title, fontWeight = FontWeight.Black, color = palette.accent)
        Spacer(Modifier.height(6.dp))
        Text(value, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = palette.text)
    }
}

@Composable
private fun StatsListCard(title: String, rows: List<String>, palette: Palette) {
    Column(
        Modifier.fillMaxWidth()
            .background(palette.card, RoundedCornerShape(18.dp))
            .border(2.dp, palette.card2, RoundedCornerShape(18.dp))
            .padding(16.dp)
    ) {
        Text(title, fontWeight = FontWeight.Black, color = palette.accent)
        Spacer(Modifier.height(6.dp))
        if (rows.isEmpty()) Text("Ingen statistik ännu", color = palette.muted)
        rows.forEachIndexed { index, row ->
            Text("${index + 1}. $row", fontSize = 18.sp, color = palette.text)
        }
    }
}

@Composable
private fun EditDialog(
    item: ShoppingItem,
    palette: Palette,
    onDismiss: () -> Unit,
    onSave: (String, String) -> Unit
) {
    var name by remember(item.id) { mutableStateOf(item.name) }
    var qty by remember(item.id) { mutableStateOf(item.quantity) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = palette.card,
        title = { Text("REDIGERA", color = palette.text, fontWeight = FontWeight.Black) },
        text = {
            Column {
                RetroField(name, { name = it }, "Vara", Modifier.fillMaxWidth(), palette)
                Spacer(Modifier.height(8.dp))
                RetroField(qty, { qty = it }, "Mängd", Modifier.fillMaxWidth(), palette)
            }
        },
        confirmButton = {
            RetroButton("SPARA", {
                if (name.trim().isNotEmpty()) onSave(name.trim(), qty.trim())
            }, palette)
        },
        dismissButton = { RetroButton("AVBRYT", onDismiss, palette) }
    )
}

@Composable
private fun RetroField(
    value: String,
    onValueChange: (String) -> Unit,
    placeholder: String,
    modifier: Modifier,
    palette: Palette,
    onDone: () -> Unit = {}
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        modifier = modifier,
        singleLine = true,
        placeholder = { Text(placeholder, color = palette.muted) },
        keyboardActions = KeyboardActions(onDone = { onDone() }),
        colors = OutlinedTextFieldDefaults.colors(
            focusedTextColor = palette.text,
            unfocusedTextColor = palette.text,
            focusedBorderColor = palette.accent,
            unfocusedBorderColor = palette.card2,
            cursorColor = palette.accent,
            focusedContainerColor = palette.card,
            unfocusedContainerColor = palette.card
        ),
        shape = RoundedCornerShape(14.dp)
    )
}

@Composable
private fun RetroButton(
    text: String,
    onClick: () -> Unit,
    palette: Palette,
    modifier: Modifier = Modifier,
    danger: Boolean = false,
    selected: Boolean = false
) {
    Button(
        onClick = onClick,
        modifier = modifier,
        colors = ButtonDefaults.buttonColors(
            containerColor = when {
                danger -> palette.red
                selected -> palette.accent
                else -> palette.card2
            },
            contentColor = if (selected) Color(0xFF2A211B) else palette.text
        ),
        shape = RoundedCornerShape(12.dp),
        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 10.dp)
    ) {
        Text(text, fontWeight = FontWeight.Black)
    }
}
