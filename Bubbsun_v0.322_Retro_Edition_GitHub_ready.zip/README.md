# Bubbsun v0.322 – Retro Edition

Androidprojekt för Bubbsun.

## Nytt i v0.322

- Designen på sidan för att lägga till varor följer variant 6.
- Etiketterna visar hela `VARA` och `MÄNGD/ENHET` utan dekorationspunkter.
- Vara- och mängdfälten har samma höjd.
- Mängdfältet är bredare och visar `Valfri` på en rad.
- Ingen annan funktionalitet är ändrad.

## Bygga APK på GitHub

Lägg projektets uppackade innehåll i repot. Workflow-filen ska ligga i:

`.github/workflows/build-apk.yml`

APK-filen hittas efter bygget under **Actions → Artifacts**.
