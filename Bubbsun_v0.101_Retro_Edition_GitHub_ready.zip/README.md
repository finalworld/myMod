# Bubbsun v0.101 – Retro Edition

Detta är uppgraderingen från v0.04 med retrodesign och felrättningar.

## Viktigaste ändringarna
- Säker marginal mot statusfält och navigationsfält
- Telefonens tillbaka-knapp går tillbaka i appen
- Retrodesign med papper, grönt, guld och stora knappar
- Direkt uppdatering vid avbockning och redigering
- Automatisk stor bokstav
- Autofyllning direkt under inmatningsfältet
- Raderingsläge med markera alla och bekräftelse
- Bekräftelse vid radering av lista
- Förbättrad långtryck-och-dra-sortering
- Statistik: 1 vecka, 1 månad, 1 år och livstid
- Reset av statistik med bekräftelse
- Flera användare och 16 färger

## Bygga med din befintliga GitHub-lösning
Din workflow-fil i GitHub behöver packa upp filen du laddar upp. Ändra unzip-raden till:

```yaml
run: unzip Bubbsun_v0.101_Retro_Edition_GitHub_ready.zip -d bubbsun
```

Ladda därefter upp zip-filen och kör Actions.


## v0.101
- Rättar Kotlin-kompileringsfelet i färgväljaren för användare.
