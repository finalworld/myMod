package se.bubbsun.app

import android.content.Context
import android.content.Intent
import android.app.Activity
import java.util.Locale
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID
import kotlin.math.abs
import kotlin.math.sign
import kotlin.random.Random
import kotlinx.coroutines.launch

private val listIcons = listOf("🛒","🧺","🍎","🍴","🏋","🏃","🚲","🥾","💼","💻","📚","✏","🏠","🛋","🐾","♥")
private val iconColors = listOf(0xFF2B6F73,0xFF9B3F2D,0xFF597A3B,0xFF8C6337,0xFF50677A,0xFF7A6B3B)

data class UserProfile(val id:String=UUID.randomUUID().toString(), var name:String, var colorHex:Long)
class ShoppingItem(
    val id:String=UUID.randomUUID().toString(), name:String, quantity:String="", ownerId:String,
    completed:Boolean=false, val createdAt:Long=System.currentTimeMillis(), completedAt:Long?=null
){ var name by mutableStateOf(name); var quantity by mutableStateOf(quantity); var ownerId by mutableStateOf(ownerId); var completed by mutableStateOf(completed); var completedAt by mutableStateOf(completedAt) }
class ShoppingListData(
    val id:String=UUID.randomUUID().toString(), name:String, icon:String="🛒", iconColorHex:Long=0xFF2B6F73,
    items:List<ShoppingItem> = emptyList()
){ var name by mutableStateOf(name); var icon by mutableStateOf(icon); var iconColorHex by mutableStateOf(iconColorHex); val items=mutableStateListOf<ShoppingItem>().apply{addAll(items)} }
data class StatEvent(val id:String=UUID.randomUUID().toString(),val kind:String,val itemName:String,val userId:String,val timestamp:Long=System.currentTimeMillis())

class MainActivity:ComponentActivity(){ override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);setContent{BubbsunApp(applicationContext)}} }

private class BubbsunStore(context:Context){
    private val prefs=context.getSharedPreferences("bubbsun_store",Context.MODE_PRIVATE)
    fun loadUsers():MutableList<UserProfile>{
        val raw=prefs.getString("users_v010",null)?:return mutableListOf(UserProfile("frasse","Frasse",0xFFFFC928))
        return runCatching{val a=JSONArray(raw);MutableList(a.length()){i->val o=a.getJSONObject(i);UserProfile(o.getString("id"),o.getString("name"),o.getLong("color"))}}.getOrElse{mutableListOf(UserProfile("frasse","Frasse",0xFFFFC928))}
    }
    fun saveUsers(users:List<UserProfile>){val a=JSONArray();users.forEach{u->a.put(JSONObject().apply{put("id",u.id);put("name",u.name);put("color",u.colorHex)})};prefs.edit().putString("users_v010",a.toString()).apply()}
    fun loadLists(users:List<UserProfile>):MutableList<ShoppingListData>{
        val raw=prefs.getString("lists",null)?:return mutableListOf(ShoppingListData(name="Matinköp",icon="🛒"))
        val danne=users.firstOrNull{it.name.equals("Danne",true)}?.id?:users.first().id;val sanja=users.firstOrNull{it.name.equals("Sanja",true)}?.id?:users.first().id
        return runCatching{val a=JSONArray(raw);MutableList(a.length()){i->val o=a.getJSONObject(i);val loaded=mutableListOf<ShoppingItem>();val ia=o.optJSONArray("items")?:JSONArray();repeat(ia.length()){j->val it=ia.getJSONObject(j);val legacy=it.optString("owner","DANNE");loaded+=ShoppingItem(it.optString("id",UUID.randomUUID().toString()),it.optString("name",""),it.optString("quantity",""),it.optString("ownerId",if(legacy=="SANJA")sanja else danne),it.optBoolean("completed",false),it.optLong("createdAt",System.currentTimeMillis()),if(it.isNull("completedAt"))null else it.optLong("completedAt"))};ShoppingListData(o.optString("id",UUID.randomUUID().toString()),o.optString("name","Lista"),o.optString("icon",listIcons[i%listIcons.size]),o.optLong("iconColor",iconColors[i%iconColors.size]),loaded)}}.getOrElse{mutableListOf(ShoppingListData(name="Matinköp"))}
    }
    fun saveLists(lists:List<ShoppingListData>){val a=JSONArray();lists.forEach{l->val ia=JSONArray();l.items.forEach{it->ia.put(JSONObject().apply{put("id",it.id);put("name",it.name);put("quantity",it.quantity);put("ownerId",it.ownerId);put("completed",it.completed);put("createdAt",it.createdAt);put("completedAt",it.completedAt?:JSONObject.NULL)})};a.put(JSONObject().apply{put("id",l.id);put("name",l.name);put("icon",l.icon);put("iconColor",l.iconColorHex);put("items",ia)})};prefs.edit().putString("lists",a.toString()).apply()}
    fun loadEvents():MutableList<StatEvent>{val raw=prefs.getString("events_v010",null)?:return mutableListOf();return runCatching{val a=JSONArray(raw);MutableList(a.length()){i->val o=a.getJSONObject(i);StatEvent(o.getString("id"),o.getString("kind"),o.getString("itemName"),o.optString("userId",""),o.getLong("timestamp"))}}.getOrElse{mutableListOf()}}
    fun saveEvents(events:List<StatEvent>){val a=JSONArray();events.forEach{e->a.put(JSONObject().apply{put("id",e.id);put("kind",e.kind);put("itemName",e.itemName);put("userId",e.userId);put("timestamp",e.timestamp)})};prefs.edit().putString("events_v010",a.toString()).apply()}
    fun loadThemeId():String=prefs.getString("theme_v0340",null) ?: if(prefs.getBoolean("dark",true)) "retro_dark" else "retro_light"
    fun saveThemeId(id:String)=prefs.edit().putString("theme_v0340",id).apply()
    fun loadUserId(d:String)=prefs.getString("active_user_v010",d)?:d;fun saveUserId(id:String)=prefs.edit().putString("active_user_v010",id).apply()
    fun loadLanguage():String=prefs.getString("language_v0400",null) ?: if(Locale.getDefault().language.equals("sv",true)) "sv" else "en"
    fun saveLanguage(value:String)=prefs.edit().putString("language_v0400",value).apply()
    fun loadExitConfirmation():Boolean=prefs.getBoolean("exit_confirmation_v0400",true)
    fun saveExitConfirmation(value:Boolean)=prefs.edit().putBoolean("exit_confirmation_v0400",value).apply()
    fun loadInputExpanded():Boolean=prefs.getBoolean("input_expanded_v0400",true)
    fun saveInputExpanded(value:Boolean)=prefs.edit().putBoolean("input_expanded_v0400",value).apply()
}

data class Palette(
    val bg:Color,val top:Color,val panel:Color,val paper:Color,val paper2:Color,
    val text:Color,val pageText:Color,val muted:Color,val pageMuted:Color,
    val gold:Color,val green:Color,val red:Color,val outline:Color,val glow:Color
)
data class AppTheme(val id:String,val name:String,val icon:String,val palette:Palette)
private val appThemes=listOf(
    AppTheme("retro_dark","Retro","🏛",Palette(
        Color(0xFF15120E),Color(0xFF211911),Color(0xFF2A2118),Color(0xFFD8C294),Color(0xFFC9AC76),
        Color(0xFF261E16),Color(0xFFF2E2BC),Color(0xFF65543E),Color(0xFFC8B894),
        Color(0xFFD6A83D),Color(0xFF294F4D),Color(0xFFAA3C2C),Color(0xFF6E5328),Color(0xFFFFD85E))),
    AppTheme("retro_light","Ljus retro","☀",Palette(
        Color(0xFFB6915D),Color(0xFF2C2118),Color(0xFF3A2B1C),Color(0xFFE9D7A8),Color(0xFFDCC28B),
        Color(0xFF2A2119),Color(0xFF2A2119),Color(0xFF6D5B42),Color(0xFF5B482F),
        Color(0xFFD4A93A),Color(0xFF315F5C),Color(0xFFA83A28),Color(0xFF60451F),Color(0xFFFFD85E))),
    AppTheme("ocean","Hav","🌊",Palette(
        Color(0xFF071E2B),Color(0xFF092F43),Color(0xFF0D4058),Color(0xFFD8F0F2),Color(0xFFB8DDE2),
        Color(0xFF082A37),Color(0xFFE6FAFF),Color(0xFF527B86),Color(0xFFB4DCE3),
        Color(0xFF5ED1D8),Color(0xFF087F91),Color(0xFFB64545),Color(0xFF2E7589),Color(0xFF8AF5FF))),
    AppTheme("forest","Skog","🌳",Palette(
        Color(0xFF101C13),Color(0xFF1B3020),Color(0xFF29442D),Color(0xFFE2E3C4),Color(0xFFC9D0A3),
        Color(0xFF20301F),Color(0xFFF1F1D8),Color(0xFF68755A),Color(0xFFC9D3B1),
        Color(0xFFD3B85B),Color(0xFF3E7548),Color(0xFFA34332),Color(0xFF617342),Color(0xFFF1DC72))),
    AppTheme("sunset","Solnedgång","🌅",Palette(
        Color(0xFF241126),Color(0xFF3B1837),Color(0xFF552142),Color(0xFFF1D0B0),Color(0xFFE4B58E),
        Color(0xFF3B1A29),Color(0xFFFFE4C9),Color(0xFF885E68),Color(0xFFE0B0B5),
        Color(0xFFFFB34E),Color(0xFF9A3F63),Color(0xFFB83C36),Color(0xFF8A4A59),Color(0xFFFFD071))),
    AppTheme("winter","Vinter","❄",Palette(
        Color(0xFF101A26),Color(0xFF1E3043),Color(0xFF2B435A),Color(0xFFE7F1F6),Color(0xFFC9DDE8),
        Color(0xFF203342),Color(0xFFF2FAFF),Color(0xFF657B8C),Color(0xFFC7DBE6),
        Color(0xFFA8D8F0),Color(0xFF477F9D),Color(0xFFAF4B56),Color(0xFF678DA4),Color(0xFFD6F3FF))),
    AppTheme("blossom","Blomster","🌸",Palette(
        Color(0xFF261821),Color(0xFF402536),Color(0xFF583247),Color(0xFFF3DCE7),Color(0xFFE8BED3),
        Color(0xFF3D2432),Color(0xFFFFEAF4),Color(0xFF8B6477),Color(0xFFE4BED0),
        Color(0xFFF0A9C6),Color(0xFF6E8B63),Color(0xFFB8455B),Color(0xFF956078),Color(0xFFFFCBE1))),
    AppTheme("fire","Eld","🔥",Palette(
        Color(0xFF1C0E0B),Color(0xFF351710),Color(0xFF4C2116),Color(0xFFF1D0A7),Color(0xFFE0AF75),
        Color(0xFF341B10),Color(0xFFFFE3BA),Color(0xFF8A5A3C),Color(0xFFD9B18D),
        Color(0xFFFFAA34),Color(0xFF8B3A21),Color(0xFFC33B25),Color(0xFF8A4A27),Color(0xFFFFC14D))),
    AppTheme("steel","Stål","⚙",Palette(
        Color(0xFF15191D),Color(0xFF252C33),Color(0xFF343D45),Color(0xFFDCE1E5),Color(0xFFBBC4CB),
        Color(0xFF252C31),Color(0xFFF0F4F6),Color(0xFF6C767E),Color(0xFFC6CFD5),
        Color(0xFF9FC0D3),Color(0xFF4B6878),Color(0xFFA84444),Color(0xFF657681),Color(0xFFC8E8F8))),
    AppTheme("neon","Neon","💎",Palette(
        Color(0xFF090813),Color(0xFF151127),Color(0xFF21183B),Color(0xFFE7DFFF),Color(0xFFC9B9F2),
        Color(0xFF21173A),Color(0xFFF5EFFF),Color(0xFF74658E),Color(0xFFD3C8EC),
        Color(0xFF45E6D0),Color(0xFF713DB0),Color(0xFFFF3D72),Color(0xFF6E4C9D),Color(0xFF66FFE7)))
)
private fun readableOn(color:Color)=if(color.luminance()>.45f)Color(0xFF241B14) else Color(0xFFF4E4BA)
private val userColors=listOf(0xFFFFC928,0xFFFF5E8A,0xFFFF8A2B,0xFFE84B3C,0xFF9E3F45,0xFF7846A8,0xFF3487C7,0xFF35AFC2,0xFF3BA78F,0xFF7BAD43,0xFFB4D936,0xFF8A5B35,0xFFD8B98A,0xFF244F73,0xFF9DD8B7,0xFF777777)

@Composable fun BubbsunApp(context:Context){
    val store=remember{BubbsunStore(context)}
    val users=remember{mutableStateListOf<UserProfile>().apply{addAll(store.loadUsers())}}
    val lists=remember{mutableStateListOf<ShoppingListData>().apply{addAll(store.loadLists(users))}}
    val events=remember{mutableStateListOf<StatEvent>().apply{addAll(store.loadEvents())}}
    var activeUserId by remember{mutableStateOf(store.loadUserId(users.first().id))}
    var themeId by remember{mutableStateOf(store.loadThemeId())}
    var screen by remember{mutableStateOf("lists")}
    var selectedListId by remember{mutableStateOf<String?>(null)}
    var menuOpen by remember{mutableStateOf(false)}
    var language by remember{mutableStateOf(store.loadLanguage())}
    var exitConfirmation by remember{mutableStateOf(store.loadExitConfirmation())}
    var inputExpanded by remember{mutableStateOf(store.loadInputExpanded())}
    var showExitDialog by remember{mutableStateOf(false)}
    val theme=appThemes.firstOrNull{it.id==themeId}?:appThemes.first()
    val p=theme.palette
    BackHandler {
        when {
            menuOpen -> menuOpen=false
            screen!="lists" -> {screen="lists";selectedListId=null}
            exitConfirmation -> showExitDialog=true
            else -> (context as? Activity)?.finish()
        }
    }
    val systemDensity = LocalDensity.current
    CompositionLocalProvider(LocalDensity provides Density(systemDensity.density, systemDensity.fontScale.coerceAtMost(1.35f))) {
        MaterialTheme(colorScheme=if(p.bg.luminance()<.45f)darkColorScheme() else lightColorScheme()){
            Box(Modifier.fillMaxSize().background(p.bg).safeDrawingPadding()){
                Column(Modifier.fillMaxSize()){
                    AppHeader(theme,p,onMenu={menuOpen=true},onThemeSelected={themeId=it;store.saveThemeId(it)})
                    when(screen){
                        "lists"->ListsScreen(lists,p,onOpen={selectedListId=it;screen="list"},onAdd={screen="addList"},onSave={store.saveLists(lists)})
                        "addList"->AddListScreen(p,onBack={screen="lists"},onCreate={name,icon,color->lists.add(0,ShoppingListData(name=capitalized(name),icon=icon,iconColorHex=color));store.saveLists(lists);screen="lists"})
                        "stats"->StatsScreen(lists,events,users,p,onBack={screen="lists"})
                        "settings"->SettingsScreen(p,language,exitConfirmation,onBack={screen="lists"},onLanguage={language=it;store.saveLanguage(it)},onExitConfirmation={exitConfirmation=it;store.saveExitConfirmation(it)},onResetStats={events.clear();store.saveEvents(events)})
                        "users"->UsersScreen(users,activeUserId,p,onBack={screen="lists"},onActivate={activeUserId=it;store.saveUserId(it)},onSave={if(users.none{it.id==activeUserId})activeUserId=users.first().id;store.saveUsers(users);store.saveUserId(activeUserId)})
                        "about"->AboutScreen(p,onBack={screen="lists"})
                        else->{val l=lists.firstOrNull{it.id==selectedListId};if(l==null)screen="lists" else ShoppingListScreen(l,users,activeUserId,p,inputExpanded,onInputExpanded={inputExpanded=it;store.saveInputExpanded(it)},onBack={screen="lists"},onSave={store.saveLists(lists)},onEvent={events.add(it);store.saveEvents(events)})}
                    }
                }
                if(menuOpen)SideMenu(users,activeUserId,p,onClose={menuOpen=false},onActivate={activeUserId=it;store.saveUserId(it)},onNavigate={menuOpen=false;screen=it})
                if(showExitDialog) ConfirmDialog("Avsluta Bubbsun?","Vill du stänga appen?",p,{showExitDialog=false},{showExitDialog=false;(context as? Activity)?.finish()},confirmLabel="AVSLUTA")
            }
        }
    }
}

@Composable private fun AppHeader(theme:AppTheme,p:Palette,onMenu:()->Unit,onThemeSelected:(String)->Unit){
    var themeMenu by remember{mutableStateOf(false)}
    Row(Modifier.fillMaxWidth().background(p.top).padding(horizontal=12.dp,vertical=10.dp),verticalAlignment=Alignment.CenterVertically){
        SquareIcon("☰",onMenu,p,large=true)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f),horizontalAlignment=Alignment.CenterHorizontally){
            Text("Bubbsun",fontFamily=FontFamily.Cursive,fontStyle=FontStyle.Italic,fontWeight=FontWeight.Black,fontSize=38.sp,color=Color(0xFFC94F32),modifier=Modifier.shadow(1.dp))
            Text("★  LISTOR MED KARAKTÄR  ★",fontFamily=FontFamily.Serif,fontWeight=FontWeight.Bold,fontSize=10.sp,color=p.gold)
        }
        Spacer(Modifier.width(8.dp))
        Box{
            SquareIcon(theme.icon,{themeMenu=true},p,large=true)
            DropdownMenu(expanded=themeMenu,onDismissRequest={themeMenu=false},modifier=Modifier.width(260.dp).background(p.panel)){
                Text("VÄLJ TEMA",color=p.gold,fontFamily=FontFamily.Serif,fontWeight=FontWeight.Black,fontSize=15.sp,modifier=Modifier.padding(horizontal=16.dp,vertical=10.dp))
                appThemes.forEach{option->
                    val selected=option.id==theme.id
                    DropdownMenuItem(
                        text={Column{Text(option.name,color=readableOn(p.panel),fontFamily=FontFamily.Serif,fontWeight=FontWeight.Black,fontSize=18.sp);Row(horizontalArrangement=Arrangement.spacedBy(5.dp)){listOf(option.palette.gold,option.palette.green,option.palette.bg).forEach{c->Box(Modifier.size(10.dp).clip(CircleShape).background(c))}}}},
                        leadingIcon={Text(option.icon,fontSize=25.sp)},
                        trailingIcon=if(selected){{Text("✓",color=p.gold,fontSize=21.sp,fontWeight=FontWeight.Black)}}else null,
                        onClick={onThemeSelected(option.id);themeMenu=false},
                        modifier=Modifier.padding(horizontal=6.dp,vertical=2.dp).clip(RoundedCornerShape(10.dp)).then(if(selected)Modifier.background(p.gold.copy(alpha=.18f)).border(1.dp,p.gold,RoundedCornerShape(10.dp))else Modifier)
                    )
                }
            }
        }
    }
}

@Composable private fun SideMenu(users:List<UserProfile>,activeId:String,p:Palette,onClose:()->Unit,onActivate:(String)->Unit,onNavigate:(String)->Unit){
    var chooser by remember{mutableStateOf(false)}
    val active=users.firstOrNull{it.id==activeId}?:users.first()
    Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha=.62f)).clickable{onClose()}){
        Column(
            Modifier.fillMaxHeight().fillMaxWidth(.84f).background(p.top).padding(18.dp).clickable(enabled=false){},
            verticalArrangement=Arrangement.Top
        ){
            Row(verticalAlignment=Alignment.CenterVertically){
                Column(Modifier.weight(1f)){Text("Bubbsun",fontFamily=FontFamily.Cursive,fontStyle=FontStyle.Italic,fontWeight=FontWeight.Black,fontSize=35.sp,color=Color(0xFFC94F32));Text("MENY",color=p.gold,fontFamily=FontFamily.Serif,fontWeight=FontWeight.Black,fontSize=12.sp,letterSpacing=2.sp)}
                SquareIcon("×",onClose,p,large=true)
            }
            Spacer(Modifier.height(20.dp))
            Text("AKTIV ANVÄNDARE",fontFamily=FontFamily.Serif,fontWeight=FontWeight.Black,fontSize=12.sp,color=p.gold,letterSpacing=1.2.sp)
            Spacer(Modifier.height(8.dp))
            Box{
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(p.panel).border(2.dp,p.gold,RoundedCornerShape(16.dp)).clickable{chooser=true}.padding(15.dp),verticalAlignment=Alignment.CenterVertically){
                    Box(Modifier.size(52.dp).clip(CircleShape).background(Color(active.colorHex)).border(3.dp,p.gold,CircleShape),contentAlignment=Alignment.Center){Text(active.name.take(1).uppercase(),color=readableOn(Color(active.colorHex)),fontWeight=FontWeight.Black,fontSize=22.sp)}
                    Spacer(Modifier.width(13.dp));Column(Modifier.weight(1f)){Text(active.name,color=readableOn(p.panel),fontFamily=FontFamily.Serif,fontWeight=FontWeight.Black,fontSize=22.sp);Text("Tryck för att byta",color=p.gold,fontSize=12.sp)};Text("⌄",color=p.gold,fontSize=28.sp)
                }
                DropdownMenu(chooser,{chooser=false},modifier=Modifier.width(280.dp).background(p.panel)){
                    users.forEach{u->DropdownMenuItem(
                        text={Text(u.name,color=readableOn(p.panel),fontFamily=FontFamily.Serif,fontWeight=FontWeight.Black,fontSize=20.sp)},
                        onClick={onActivate(u.id);chooser=false},
                        leadingIcon={Box(Modifier.size(26.dp).clip(CircleShape).background(Color(u.colorHex)).border(1.dp,p.gold,CircleShape))},
                        modifier=Modifier.heightIn(min=58.dp)
                    )}
                }
            }
            Spacer(Modifier.height(18.dp))
            MenuCard("👤","ANVÄNDARE","Hantera användare",p){onNavigate("users")}
            Spacer(Modifier.height(10.dp))
            MenuCard("▥","STATISTIK","Se listor, köp och aktivitet",p){onNavigate("stats")}
            Spacer(Modifier.height(10.dp))
            MenuCard("⚙","INSTÄLLNINGAR","Språk, bekräftelser & statistik",p){onNavigate("settings")}
            Spacer(Modifier.height(10.dp))
            MenuCard("ⓘ","OM BUBBSUN","Version, skapare & kontakt",p){onNavigate("about")}
            Spacer(Modifier.weight(1f))
            Text("v0.400  •  Retro Edition",color=p.gold.copy(alpha=.85f),fontFamily=FontFamily.Serif,fontSize=13.sp,modifier=Modifier.align(Alignment.CenterHorizontally).padding(bottom=6.dp))
        }
    }
}

@Composable private fun MenuCard(icon:String,title:String,subtitle:String,p:Palette,onClick:()->Unit){
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(15.dp)).background(p.panel).border(1.dp,p.outline,RoundedCornerShape(15.dp)).clickable{onClick()}.padding(horizontal=15.dp,vertical=14.dp),verticalAlignment=Alignment.CenterVertically){
        Box(Modifier.size(48.dp).clip(RoundedCornerShape(12.dp)).background(p.gold.copy(alpha=.16f)).border(1.dp,p.gold,RoundedCornerShape(12.dp)),contentAlignment=Alignment.Center){Text(icon,fontSize=25.sp,color=p.gold)}
        Spacer(Modifier.width(13.dp));Column(Modifier.weight(1f)){Text(title,color=readableOn(p.panel),fontFamily=FontFamily.Serif,fontWeight=FontWeight.Black,fontSize=18.sp);Text(subtitle,color=p.gold.copy(alpha=.9f),fontSize=12.sp)};Text("›",color=p.gold,fontSize=30.sp)
    }
}

@Composable private fun ListsScreen(lists:SnapshotStateList<ShoppingListData>,p:Palette,onOpen:(String)->Unit,onAdd:()->Unit,onSave:()->Unit){
    var deleteTarget by remember{mutableStateOf<ShoppingListData?>(null)}
    var draggingId by remember{mutableStateOf<String?>(null)}
    var deleteZoneTop by remember{mutableStateOf(Float.MAX_VALUE)}
    var overDeleteZone by remember{mutableStateOf(false)}

    Column(Modifier.fillMaxSize().padding(12.dp)){
        RetroTitle("★  DINA LISTOR  ★",p)
        Spacer(Modifier.height(10.dp))
        LazyColumn(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(7.dp)){
            items(lists,key={it.id}){l->
                ListRow(
                    list=l,
                    p=p,
                    dragging=draggingId==l.id,
                    onOpen={onOpen(l.id)},
                    onDragStart={draggingId=l.id;overDeleteZone=false},
                    onDragPosition={centerY->overDeleteZone=centerY>=deleteZoneTop},
                    onDragEnd={centerY->
                        val dropped=centerY>=deleteZoneTop
                        draggingId=null
                        overDeleteZone=false
                        if(dropped) deleteTarget=l
                    },
                    onMove={dir->
                        val from=lists.indexOf(l)
                        val to=(from+dir).coerceIn(0,lists.lastIndex)
                        if(from!=to){lists.removeAt(from);lists.add(to,l);onSave();true}else false
                    }
                )
            }
        }
        if(draggingId==null){
            RetroButton("＋  LÄGG TILL NY LISTA",onAdd,p,modifier=Modifier.fillMaxWidth())
        }else{
            Box(
                Modifier.fillMaxWidth().height(62.dp)
                    .onGloballyPositioned{deleteZoneTop=it.positionInRoot().y}
                    .clip(RoundedCornerShape(10.dp))
                    .background(if(overDeleteZone) Color(0xFFD74632) else p.red)
                    .border(if(overDeleteZone)4.dp else 2.dp,Color(0xFFF6E8C3),RoundedCornerShape(10.dp)),
                contentAlignment=Alignment.Center
            ){
                Text("🗑  TA BORT",color=Color(0xFFF6E8C3),fontFamily=FontFamily.Serif,fontWeight=FontWeight.Black,fontSize=19.sp)
            }
        }
    }
    deleteTarget?.let{l->ConfirmDialog("Ta bort listan \"${l.name}\"?","Alla saker i listan försvinner.",p,{deleteTarget=null},{lists.remove(l);deleteTarget=null;onSave()})}
}

@Composable private fun ListRow(list:ShoppingListData,p:Palette,dragging:Boolean,onOpen:()->Unit,onDragStart:()->Unit,onDragPosition:(Float)->Unit,onDragEnd:(Float)->Unit,onMove:(Int)->Boolean){
    val haptic=LocalHapticFeedback.current
    var dragY by remember{mutableStateOf(0f)}
    var rowCenterY by remember{mutableStateOf(0f)}
    var reorderDrag by remember{mutableStateOf(0f)}
    val rowStepPx=with(LocalDensity.current){85.dp.toPx()}
    val bg by animateColorAsState(if(dragging)p.glow else p.paper,label="drag")
    Row(
        Modifier.fillMaxWidth()
            .onGloballyPositioned{rowCenterY=it.positionInRoot().y+it.size.height/2f}
            .graphicsLayer{translationY=if(dragging)dragY else 0f;shadowElevation=if(dragging)18f else 0f}
            .shadow(if(dragging)9.dp else 2.dp,RoundedCornerShape(10.dp))
            .clip(RoundedCornerShape(10.dp)).background(bg)
            .border(if(dragging)3.dp else 2.dp,if(dragging)p.gold else p.outline,RoundedCornerShape(10.dp))
            .pointerInput(list.id){
                detectDragGesturesAfterLongPress(
                    onDragStart={
                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                        dragY=0f;reorderDrag=0f;onDragStart();onDragPosition(rowCenterY)
                    },
                    onDragEnd={val center=rowCenterY+dragY;onDragEnd(center);dragY=0f;reorderDrag=0f},
                    onDragCancel={onDragEnd(Float.NEGATIVE_INFINITY);dragY=0f;reorderDrag=0f},
                    onDrag={change,amount->
                        change.consume();dragY+=amount.y;reorderDrag+=amount.y
                        if(abs(reorderDrag)>rowStepPx*.62f){
                            val dir=if(reorderDrag>0)1 else -1
                            if(onMove(dir)){
                                // Layouten flyttar raden ett steg. Motkompensera så kortet stannar under fingret.
                                dragY-=dir*rowStepPx
                            }
                            reorderDrag=0f
                        }
                        onDragPosition(rowCenterY+dragY)
                    }
                )
            }
            .clickable(enabled=!dragging){onOpen()},
        verticalAlignment=Alignment.CenterVertically
    ){
        Box(
            Modifier.width(90.dp).height(78.dp).background(Color(list.iconColorHex)),
            contentAlignment=Alignment.Center
        ){Text(list.icon,fontSize=31.sp)}
        Column(Modifier.weight(1f).height(78.dp).padding(horizontal=12.dp,vertical=8.dp),verticalArrangement=Arrangement.Center){
            Text(list.name,fontFamily=FontFamily.Serif,fontWeight=FontWeight.Black,fontSize=when{list.name.length<=14->21.sp;list.name.length<=24->18.sp;else->15.sp},color=p.text,maxLines=2,overflow=TextOverflow.Ellipsis,lineHeight=when{list.name.length<=14->23.sp;list.name.length<=24->20.sp;else->17.sp})
            Text("${list.items.size} objekt",fontWeight=FontWeight.Bold,color=p.text,fontSize=13.sp)
        }
        Text("›",fontSize=35.sp,fontWeight=FontWeight.Bold,color=p.text,modifier=Modifier.padding(horizontal=14.dp))
    }
}

@Composable private fun AddListScreen(p:Palette,onBack:()->Unit,onCreate:(String,String,Long)->Unit){
    var name by remember{mutableStateOf("")};var icon by remember{mutableStateOf(listIcons.first())};var color by remember{mutableStateOf(iconColors.first())}
    Column(Modifier.fillMaxSize().padding(14.dp)){
        PageHeader("LÄGG TILL NY LISTA",p,onBack)
        Spacer(Modifier.height(12.dp))
        LazyColumn(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(10.dp)){
            item{Text("LISTNAMN",fontWeight=FontWeight.Black,color=p.pageText)}
            item{RetroField(name,{name=it.take(40)},"Skriv listans namn…",Modifier.fillMaxWidth(),p)}
            item{Text("VÄLJ FÄRG",fontWeight=FontWeight.Black,color=p.pageText)}
            item{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){iconColors.forEach{c->Box(Modifier.size(43.dp).clip(CircleShape).background(Color(c)).border(if(c==color)4.dp else 1.dp,if(c==color)p.gold else p.outline,CircleShape).clickable{color=c})}}}
            item{Text("VÄLJ IKON",fontWeight=FontWeight.Black,color=p.pageText)}
            items(listIcons.chunked(4)){row->
                Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(9.dp)){
                    row.forEach{i->val selected=i==icon;Box(Modifier.weight(1f).aspectRatio(1f).clip(RoundedCornerShape(9.dp)).background(if(selected)Color(color) else p.paper).border(if(selected)3.dp else 2.dp,if(selected)p.gold else p.outline,RoundedCornerShape(9.dp)).clickable{icon=i}.padding(8.dp),contentAlignment=Alignment.Center){Text(i,fontSize=30.sp)}}
                }
            }
            item{Spacer(Modifier.height(4.dp))}
        }
        Spacer(Modifier.height(10.dp))
        RetroButton("SKAPA LISTA",{if(name.isNotBlank())onCreate(name,icon,color)},p,modifier=Modifier.fillMaxWidth())
    }
}

@Composable
private fun ShoppingListScreen(
    list: ShoppingListData,
    users: List<UserProfile>,
    activeUserId: String,
    p: Palette,
    inputExpanded: Boolean,
    onInputExpanded: (Boolean) -> Unit,
    onBack: () -> Unit,
    onSave: () -> Unit,
    onEvent: (StatEvent) -> Unit
) {
    var input by remember { mutableStateOf("") }
    var quantityInput by remember { mutableStateOf("") }
    var showDone by remember { mutableStateOf(true) }
    var editing by remember { mutableStateOf<ShoppingItem?>(null) }
    var renameList by remember { mutableStateOf(false) }
    var deleteMode by remember { mutableStateOf(false) }
    val selected = remember { mutableStateListOf<String>() }
    var confirmDelete by remember { mutableStateOf(false) }
    var draggingId by remember { mutableStateOf<String?>(null) }
    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()

    val active = list.items.filter { !it.completed }
    val done = list.items.filter { it.completed }.sortedByDescending { it.completedAt ?: 0L }
    val suggestions = remember(input, list.items.size) {
        if (input.length < 1) emptyList() else list.items.map { it.name }.distinct()
            .filter { it.contains(input, ignoreCase = true) && !it.equals(input, true) }.take(5)
    }

    fun save() = onSave()
    fun addItem(raw: String, quantity: String = quantityInput) {
        val name = capitalized(raw)
        if (name.isBlank()) return
        val existing = list.items.firstOrNull { it.name.equals(name, ignoreCase = true) }
        if (existing == null) list.items.add(0, ShoppingItem(name = name, quantity = quantity.trim(), ownerId = activeUserId))
        else {
            existing.completed = false; existing.completedAt = null; existing.ownerId = activeUserId; existing.quantity = quantity.trim()
            list.items.remove(existing); list.items.add(0, existing)
        }
        input = ""; quantityInput = ""; save()
        scope.launch { if (list.items.isNotEmpty()) listState.animateScrollToItem(0) }
    }

    Column(Modifier.fillMaxSize().imePadding().padding(12.dp)) {
        PageHeader(title = list.name, p = p, onBack = onBack, trailing = {
            Row {
                EditButton({ renameList = true }, p)
                Spacer(Modifier.width(6.dp))
                DeleteButton(onClick = {
                    if (deleteMode) { if (selected.isEmpty()) deleteMode = false else confirmDelete = true }
                    else deleteMode = true
                }, p = p)
            }
        })
        Spacer(Modifier.height(10.dp))
        InputPanel(product=input,onProductChange={input=it},quantity=quantityInput,onQuantityChange={quantityInput=it},onAdd={addItem(input)},expanded=inputExpanded,onExpandedChange=onInputExpanded,p=p)
        if (suggestions.isNotEmpty()) {
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp)).background(p.paper).border(1.dp,p.outline,RoundedCornerShape(8.dp))) {
                suggestions.forEach { suggestion ->
                    Text(suggestion, color=p.text, fontWeight=FontWeight.Bold,
                        modifier=Modifier.fillMaxWidth().clickable { input=suggestion }.padding(horizontal=14.dp,vertical=9.dp))
                }
            }
        }
        Spacer(Modifier.height(10.dp))
        if (deleteMode) {
            val allIds = list.items.map { it.id }; val allSelected = allIds.isNotEmpty() && selected.containsAll(allIds)
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp)).background(p.panel).padding(horizontal=10.dp,vertical=8.dp),verticalAlignment=Alignment.CenterVertically) {
                Checkbox(checked=allSelected,onCheckedChange={selected.clear();if(!allSelected)selected.addAll(allIds)},colors=CheckboxDefaults.colors(checkedColor=p.red,uncheckedColor=p.green,checkmarkColor=Color.White))
                Text("MARKERA ALLA",fontFamily=FontFamily.Serif,fontWeight=FontWeight.Black,color=Color(0xFFF6E8C3),modifier=Modifier.clickable{selected.clear();if(!allSelected)selected.addAll(allIds)})
                Spacer(Modifier.weight(1f));Text("AVBRYT",fontWeight=FontWeight.Black,color=Color(0xFFF6E8C3),modifier=Modifier.clickable{selected.clear();deleteMode=false}.padding(8.dp))
            };Spacer(Modifier.height(8.dp))
        }
        LazyColumn(state=listState,modifier=Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(6.dp)) {
            items(active,key={it.id}) { item ->
                ItemRow(item,users,p,deleteMode,selected.contains(item.id),draggingId==item.id,
                    onSelect={if(item.id in selected)selected.remove(item.id) else selected.add(item.id)},
                    onToggle={item.completed=true;item.completedAt=System.currentTimeMillis();onEvent(StatEvent(kind="purchase",itemName=item.name,userId=item.ownerId));save()},
                    onEdit={editing=item},onDragStart={draggingId=item.id},onDragEnd={draggingId=null},
                    onMove={direction->val current=list.items.filter{!it.completed};val from=current.indexOf(item);val to=(from+direction).coerceIn(0,current.lastIndex);if(from!=to){val other=current[to];val a=list.items.indexOf(item);val b=list.items.indexOf(other);list.items[a]=other;list.items[b]=item;save();true}else false})
            }
            item { Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp)).background(p.green).clickable{showDone=!showDone}.padding(10.dp)) { Text(if(showDone)"KLART (${done.size})  ▲" else "KLART (${done.size})  ▼",fontFamily=FontFamily.Serif,fontWeight=FontWeight.Black,color=Color.White) } }
            if(showDone) items(done,key={"d${it.id}"}) { item ->
                ItemRow(item,users,p,deleteMode,selected.contains(item.id),false,
                    onSelect={if(item.id in selected)selected.remove(item.id) else selected.add(item.id)},
                    onToggle={item.completed=false;item.completedAt=null;list.items.remove(item);list.items.add(0,item);save()},
                    onEdit={editing=item},onDragStart={},onDragEnd={},onMove={false})
            }
        }
    }
    if(renameList) EditListDialog(list,p,{renameList=false}) { name,icon,color -> list.name=capitalized(name).take(40);list.icon=icon;list.iconColorHex=color;renameList=false;save() }
    editing?.let { item -> EditDialog(item,p,{editing=null}) { n,q -> item.name=capitalized(n);item.quantity=q.trim();editing=null;save() } }
    if(confirmDelete) ConfirmDialog("Ta bort ${selected.size} markerade saker?","Det går inte att ångra.",p,{confirmDelete=false},{val doomed=list.items.filter{it.id in selected};doomed.forEach{onEvent(StatEvent(kind="delete",itemName=it.name,userId=it.ownerId))};list.items.removeAll(doomed);selected.clear();deleteMode=false;confirmDelete=false;save()})
}

@Composable private fun ItemRow(item:ShoppingItem,users:List<UserProfile>,p:Palette,deleteMode:Boolean,isSelected:Boolean,dragging:Boolean,onSelect:()->Unit,onToggle:()->Unit,onEdit:()->Unit,onDragStart:()->Unit,onDragEnd:()->Unit,onMove:(Int)->Boolean){
    val haptic=LocalHapticFeedback.current
    var dragY by remember{mutableStateOf(0f)}
    var reorderDrag by remember{mutableStateOf(0f)}
    val rowStepPx=with(LocalDensity.current){72.dp.toPx()}
    val bg by animateColorAsState(if(dragging)p.glow else p.paper,label="itemdrag")
    val owner=users.firstOrNull{it.id==item.ownerId}
    Row(
        Modifier.fillMaxWidth()
            .graphicsLayer{translationY=if(dragging)dragY else 0f;shadowElevation=if(dragging)16f else 0f}
            .shadow(if(dragging)8.dp else 1.dp,RoundedCornerShape(8.dp))
            .clip(RoundedCornerShape(8.dp)).background(bg)
            .border(if(dragging)3.dp else 1.dp,if(dragging)p.gold else p.outline,RoundedCornerShape(8.dp)),
        verticalAlignment=Alignment.CenterVertically
    ){
        if(owner!=null) Box(Modifier.width(8.dp).height(66.dp).background(Color(owner.colorHex)))
        Checkbox(
            checked=item.completed,
            onCheckedChange={onToggle()},
            colors=CheckboxDefaults.colors(checkedColor=p.green,uncheckedColor=p.green,checkmarkColor=Color(0xFFF4E4BA))
        )
        Spacer(Modifier.width(3.dp))
        Row(
            Modifier.weight(1f)
                .pointerInput(item.id,deleteMode,item.completed){
                    if(!deleteMode && !item.completed){
                        detectDragGesturesAfterLongPress(
                            onDragStart={haptic.performHapticFeedback(HapticFeedbackType.LongPress);onDragStart();dragY=0f;reorderDrag=0f},
                            onDragEnd={onDragEnd();dragY=0f;reorderDrag=0f},
                            onDragCancel={onDragEnd();dragY=0f;reorderDrag=0f},
                            onDrag={change,amount->
                                change.consume();dragY+=amount.y;reorderDrag+=amount.y
                                if(abs(reorderDrag)>rowStepPx*.58f){
                                    val dir=if(reorderDrag>0)1 else -1
                                    if(onMove(dir)) dragY-=dir*rowStepPx
                                    reorderDrag=0f
                                }
                            }
                        )
                    }
                }
                .clickable(enabled=!dragging){onEdit()}
                .padding(vertical=9.dp),
            verticalAlignment=Alignment.CenterVertically
        ){
            Column(Modifier.weight(1f)){
                Text(item.name,fontFamily=FontFamily.Serif,fontWeight=FontWeight.Bold,fontSize=18.sp,color=p.text,textDecoration=if(item.completed)TextDecoration.LineThrough else null)
                if(item.quantity.isNotBlank()) Text(item.quantity,fontSize=13.sp,fontWeight=FontWeight.Bold,color=p.muted)
            }
        }
        if(deleteMode) Checkbox(isSelected,{onSelect()},colors=CheckboxDefaults.colors(checkedColor=p.red,uncheckedColor=p.red,checkmarkColor=Color.White))
    }
}

@Composable private fun UsersScreen(users:SnapshotStateList<UserProfile>,activeId:String,p:Palette,onBack:()->Unit,onActivate:(String)->Unit,onSave:()->Unit){
    var showAdd by remember{mutableStateOf(false)}
    var editTarget by remember{mutableStateOf<UserProfile?>(null)}
    var deleteTarget by remember{mutableStateOf<UserProfile?>(null)}
    Column(Modifier.fillMaxSize().padding(14.dp)){
        PageHeader("ANVÄNDARE",p,onBack);Spacer(Modifier.height(12.dp))
        LazyColumn(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(10.dp)){
            items(users,key={it.id}){u->
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(p.paper).border(if(u.id==activeId)3.dp else 2.dp,if(u.id==activeId)p.gold else p.outline,RoundedCornerShape(12.dp)).clickable{onActivate(u.id)}.padding(14.dp),verticalAlignment=Alignment.CenterVertically){
                    Box(Modifier.size(38.dp).clip(CircleShape).background(Color(u.colorHex)).border(1.dp,p.outline,CircleShape))
                    Spacer(Modifier.width(13.dp))
                    Column(Modifier.weight(1f)){Text(u.name,fontFamily=FontFamily.Serif,fontWeight=FontWeight.Black,fontSize=23.sp,color=p.text);if(u.id==activeId)Text("Aktiv användare",color=p.muted,fontSize=14.sp)}
                    RetroButton("✎",{editTarget=u},p,compact=true)
                    if(users.size>1){Spacer(Modifier.width(7.dp));DeleteButton({deleteTarget=u},p)}
                }
            }
        }
        RetroButton("＋  LÄGG TILL ANVÄNDARE",{showAdd=true},p,modifier=Modifier.fillMaxWidth())
    }
    if(showAdd)AddUserDialog(users,p,{showAdd=false},{n,c->users.add(UserProfile(name=capitalized(n),colorHex=c));showAdd=false;onSave()})
    editTarget?.let{u->EditUserDialog(u,users,p,{editTarget=null}){newName,newColor->val i=users.indexOf(u);if(i>=0)users[i]=u.copy(name=newName,colorHex=newColor);editTarget=null;onSave()}}
    deleteTarget?.let{u->ConfirmDialog("Ta bort ${u.name}?","Användaren tas bort.",p,{deleteTarget=null},{users.remove(u);deleteTarget=null;onSave()})}
}

@Composable private fun EditUserDialog(user:UserProfile,users:List<UserProfile>,p:Palette,onDismiss:()->Unit,onSave:(String,Long)->Unit){
    var name by remember{mutableStateOf(user.name)}
    var color by remember{mutableStateOf(user.colorHex)}
    var error by remember{mutableStateOf("")}
    AlertDialog(
        onDismissRequest=onDismiss,
        containerColor=p.paper,
        title={Text("REDIGERA ANVÄNDARE",fontFamily=FontFamily.Serif,fontWeight=FontWeight.Black,color=p.text)},
        text={Column{
            RetroField(name,{name=it},"Namn",Modifier.fillMaxWidth(),p)
            Spacer(Modifier.height(12.dp))
            Text("FÄRG",fontFamily=FontFamily.Serif,fontWeight=FontWeight.Black,color=p.text,fontSize=14.sp)
            Spacer(Modifier.height(8.dp))
            userColors.chunked(4).forEach{row->
                Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){
                    row.forEach{c->Box(Modifier.size(42.dp).clip(CircleShape).background(Color(c)).border(if(c==color)4.dp else 1.dp,if(c==color)p.text else p.outline,CircleShape).clickable{color=c})}
                }
                Spacer(Modifier.height(7.dp))
            }
            if(error.isNotBlank())Text(error,color=p.red)
        }},
        confirmButton={RetroButton("SPARA",{val n=capitalized(name);error=when{n.isBlank()->"Skriv ett namn";users.any{it.id!=user.id&&it.name.equals(n,true)}->"Namnet finns redan";else->""};if(error.isBlank())onSave(n,color)},p)},
        dismissButton={RetroButton("AVBRYT",onDismiss,p,danger=true)}
    )
}

@Composable private fun AddUserDialog(users:List<UserProfile>,p:Palette,onDismiss:()->Unit,onAdd:(String,Long)->Unit){var name by remember{mutableStateOf("")};var color by remember{mutableStateOf(userColors.first())};var error by remember{mutableStateOf("")};AlertDialog(onDismissRequest=onDismiss,containerColor=p.paper,title={Text("LÄGG TILL ANVÄNDARE",fontFamily=FontFamily.Serif,fontWeight=FontWeight.Black,color=p.text)},text={Column{RetroField(name,{name=it},"Namn",Modifier.fillMaxWidth(),p);Spacer(Modifier.height(12.dp));userColors.chunked(4).forEach{row->Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){row.forEach{c->Box(Modifier.size(42.dp).clip(CircleShape).background(Color(c)).border(if(c==color)4.dp else 1.dp,if(c==color)p.text else p.outline,CircleShape).clickable{color=c})}};Spacer(Modifier.height(7.dp))};if(error.isNotBlank())Text(error,color=p.red)}},confirmButton={RetroButton("SPARA",{val n=capitalized(name);error=when{n.isBlank()->"Skriv ett namn";users.any{it.name.equals(n,true)}->"Namnet finns redan";else->""};if(error.isBlank())onAdd(n,color)},p)},dismissButton={RetroButton("AVBRYT",onDismiss,p,danger=true)})}

@Composable private fun SettingsScreen(p:Palette,language:String,exitConfirmation:Boolean,onBack:()->Unit,onLanguage:(String)->Unit,onExitConfirmation:(Boolean)->Unit,onResetStats:()->Unit){
    var reset by remember{mutableStateOf(false)}
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp)){
        PageHeader(if(language=="sv")"INSTÄLLNINGAR" else "SETTINGS",p,onBack)
        Spacer(Modifier.height(14.dp))
        SettingsCard("☑",if(language=="sv")"BEKRÄFTELSER" else "CONFIRMATIONS",p){
            Row(verticalAlignment=Alignment.CenterVertically){Checkbox(exitConfirmation,onExitConfirmation,colors=CheckboxDefaults.colors(checkedColor=p.green,uncheckedColor=p.green,checkmarkColor=Color.White));Text(if(language=="sv")"Visa 'Avsluta Bubbsun?'" else "Show 'Exit Bubbsun?'",color=p.text,fontWeight=FontWeight.Bold)}
        }
        Spacer(Modifier.height(12.dp))
        SettingsCard("🌐",if(language=="sv")"SPRÅK" else "LANGUAGE",p){
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceEvenly){
                LanguageChoice("🇸🇪","Svenska",language=="sv",p){onLanguage("sv")}
                LanguageChoice("🇬🇧","English",language=="en",p){onLanguage("en")}
            }
        }
        Spacer(Modifier.height(12.dp))
        SettingsCard("📊",if(language=="sv")"STATISTIK" else "STATISTICS",p){RetroButton(if(language=="sv")"🗑  NOLLSTÄLL STATISTIK" else "🗑  RESET STATISTICS",{reset=true},p,danger=true,modifier=Modifier.fillMaxWidth())}
    }
    if(reset)ConfirmDialog(if(language=="sv")"Nollställ statistik?" else "Reset statistics?",if(language=="sv")"Detta kan inte ångras. Listor och varor påverkas inte." else "This cannot be undone. Lists and items are not affected.",p,{reset=false},{onResetStats();reset=false},confirmLabel=if(language=="sv")"NOLLSTÄLL" else "RESET")
}
@Composable private fun SettingsCard(icon:String,title:String,p:Palette,content:@Composable ColumnScope.()->Unit){Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(p.paper).border(2.dp,p.outline,RoundedCornerShape(14.dp)).padding(15.dp)){Row(verticalAlignment=Alignment.CenterVertically){Box(Modifier.size(45.dp).clip(RoundedCornerShape(10.dp)).background(p.green),contentAlignment=Alignment.Center){Text(icon,fontSize=24.sp)};Spacer(Modifier.width(11.dp));Text(title,fontFamily=FontFamily.Serif,fontWeight=FontWeight.Black,fontSize=19.sp,color=p.text)};Spacer(Modifier.height(12.dp));content()}}
@Composable private fun LanguageChoice(flag:String,label:String,selected:Boolean,p:Palette,onClick:()->Unit){Column(horizontalAlignment=Alignment.CenterHorizontally,modifier=Modifier.clickable{onClick()}.padding(8.dp)){Text(flag,fontSize=31.sp);Text(label,color=p.text,fontFamily=FontFamily.Serif,fontWeight=FontWeight.Bold);RadioButton(selected,onClick,colors=RadioButtonDefaults.colors(selectedColor=p.green,unselectedColor=p.muted))}}

enum class StatsPeriod(val label:String,val days:Int?){WEEK("1 VECKA",7),MONTH("1 MÅNAD",30),YEAR("1 ÅR",365),LIFETIME("LIVSTID",null)}
@Composable private fun StatsScreen(lists:List<ShoppingListData>,events:List<StatEvent>,users:List<UserProfile>,p:Palette,onBack:()->Unit){
    var period by remember{mutableStateOf(StatsPeriod.LIFETIME)}
    var menu by remember{mutableStateOf(false)}
    val cutoff=period.days?.let{System.currentTimeMillis()-it*86400000L}
    val filtered=events.filter{cutoff==null||it.timestamp>=cutoff}
    val purchases=filtered.filter{it.kind=="purchase"}
    val topItems=purchases.groupingBy{it.itemName}.eachCount().entries.sortedByDescending{it.value}.take(5)
    val mostActive=users.maxByOrNull{u->purchases.count{it.userId==u.id}}
    val mostActiveCount=mostActive?.let{u->purchases.count{it.userId==u.id}}?:0
    val favoriteList=lists.maxByOrNull{it.items.size}
    val totalItems=lists.sumOf{it.items.size}
    val completedNow=lists.sumOf{l->l.items.count{it.completed}}
    Column(Modifier.fillMaxSize().padding(14.dp)){
        Row(verticalAlignment=Alignment.CenterVertically){
            PageBack(onBack,p);Spacer(Modifier.width(10.dp))
            Text("STATISTIK",fontFamily=FontFamily.Serif,fontWeight=FontWeight.Black,fontSize=25.sp,color=p.pageText,modifier=Modifier.weight(1f))
            Box{RetroButton(period.label,{menu=true},p,compact=true);DropdownMenu(menu,{menu=false}){StatsPeriod.entries.forEach{x->DropdownMenuItem(text={Text(x.label)},onClick={period=x;menu=false})}}}
        }
        Spacer(Modifier.height(12.dp))
        LazyColumn(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(9.dp)){
            item{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(9.dp)){StatsCard("📋","SKAPADE LISTOR",lists.size.toString(),p,Modifier.weight(1f));StatsCard("🛒","TILLAGDA VAROR",totalItems.toString(),p,Modifier.weight(1f))}}
            item{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(9.dp)){StatsCard("✓","AVPRICKADE",completedNow.toString(),p,Modifier.weight(1f));StatsCard("★","UNDER PERIODEN",purchases.size.toString(),p,Modifier.weight(1f))}}
            item{FeatureStatCard("👤","MEST AKTIV ANVÄNDARE",if(mostActiveCount>0)"${mostActive?.name} – $mostActiveCount avprickningar" else "Ingen statistik ännu",p)}
            item{FeatureStatCard("🏆","MEST ANVÄNDA LISTA",favoriteList?.let{"${it.name} – ${it.items.size} varor"}?:"Ingen lista ännu",p)}
            item{Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(p.paper).border(2.dp,p.outline,RoundedCornerShape(10.dp)).padding(14.dp)){
                Text("MEST HANDLADE",fontFamily=FontFamily.Serif,fontWeight=FontWeight.Black,color=p.text)
                Spacer(Modifier.height(6.dp))
                if(topItems.isEmpty())Text("Ingen statistik ännu",color=p.muted)
                topItems.forEachIndexed{i,x->Text("${i+1}. ${x.key}  ·  ${x.value}",fontWeight=FontWeight.Bold,color=p.text,modifier=Modifier.padding(vertical=3.dp))}
            }}
            item{Spacer(Modifier.height(10.dp))}
        }
    }
}
@Composable private fun StatsCard(icon:String,title:String,value:String,p:Palette,modifier:Modifier=Modifier){Column(modifier.clip(RoundedCornerShape(10.dp)).background(p.paper).border(2.dp,p.outline,RoundedCornerShape(10.dp)).padding(14.dp),horizontalAlignment=Alignment.CenterHorizontally){Text(icon,fontSize=25.sp);Text(title,fontFamily=FontFamily.Serif,fontWeight=FontWeight.Black,fontSize=11.sp,color=p.text,textAlign=TextAlign.Center);Text(value,fontSize=30.sp,fontWeight=FontWeight.Black,color=p.green)}}
@Composable private fun FeatureStatCard(icon:String,title:String,value:String,p:Palette){Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(p.paper).border(2.dp,p.outline,RoundedCornerShape(10.dp)).padding(14.dp),verticalAlignment=Alignment.CenterVertically){Text(icon,fontSize=30.sp);Spacer(Modifier.width(12.dp));Column{Text(title,fontFamily=FontFamily.Serif,fontWeight=FontWeight.Black,fontSize=13.sp,color=p.text);Text(value,fontWeight=FontWeight.Bold,color=p.green)}}}

@Composable
private fun AboutScreen(p: Palette, onBack: () -> Unit) {
    val context = LocalContext.current
    val scroll = rememberScrollState()
    var ducksVisible by remember { mutableStateOf(false) }
    var tapCount by remember { mutableStateOf(0) }
    var lastTap by remember { mutableStateOf(0L) }

    fun email(subject: String) {
        val intent = Intent(Intent.ACTION_SENDTO).apply {
            data = Uri.parse("mailto:finalworld@gmail.com")
            putExtra(Intent.EXTRA_SUBJECT, subject)
        }
        runCatching { context.startActivity(intent) }
    }

    Box(Modifier.fillMaxSize()) {
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(scroll)
            .padding(14.dp)
    ) {
        PageHeader("OM BUBBSUN", p, onBack)
        Spacer(Modifier.height(12.dp))

        Row(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(p.panel)
                .border(1.dp, p.outline, RoundedCornerShape(12.dp))
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1.35f)) {
                CreditRow("👨", "Daniel Grandin", "Utveckling & design", p)
                DottedDivider(p)
                CreditRow("👩", "Sanja Kropsu", "Idéer, testning & feedback", p)
                DottedDivider(p)
                CreditRow("🐾", "Frasse", "Support & kvalitetskontroll", p)
            }

            Spacer(Modifier.width(8.dp))
            Image(
                painter = painterResource(id = R.drawable.frasse),
                contentDescription = "Frasse",
                contentScale = ContentScale.Fit,
                modifier = Modifier
                    .weight(.75f)
                    .heightIn(min = 180.dp, max = 270.dp)
                    .pointerInput(Unit) {
                        detectTapGestures(onTap = {
                            val now=System.currentTimeMillis()
                            tapCount=if(now-lastTap<700)tapCount+1 else 1
                            lastTap=now
                            if(tapCount>=3){ducksVisible=true;tapCount=0}
                        })
                    }
            )
        }

        Spacer(Modifier.height(12.dp))

        Column(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(11.dp))
                .background(p.panel)
                .border(1.dp, p.outline, RoundedCornerShape(11.dp))
                .padding(14.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("★  OM BUBBSUN  ★", color = p.gold, fontFamily = FontFamily.Serif, fontWeight = FontWeight.Black, fontSize = 18.sp)
            Spacer(Modifier.height(8.dp))
            Text(
                "Bubbsun skapades för att göra inköpslistor enkla, snabba och lite roligare – med en unik retrokänsla.",
                color = readableOn(p.panel),
                fontSize = 16.sp,
                lineHeight = 22.sp,
                textAlign = TextAlign.Center
            )
        }

        Spacer(Modifier.height(12.dp))
        AboutActionButton("🐞", "RAPPORTERA PROBLEM", "Hjälp oss att göra Bubbsun ännu bättre", p.green, p) { email("Bubbsun – rapportera problem") }
        Spacer(Modifier.height(9.dp))
        AboutActionButton("💡", "SKICKA FÖRSLAG", "Har du en idé? Vi vill gärna höra den!", Color(0xFF6B281D), p) { email("Bubbsun – förslag") }

        Spacer(Modifier.height(14.dp))
        Column(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(10.dp))
                .background(p.panel)
                .border(1.dp, p.outline, RoundedCornerShape(10.dp))
                .padding(13.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("v0.341 • Retro Edition", color = p.gold, fontFamily = FontFamily.Serif, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(5.dp))
            Text("© 2026 Bubbsun", color = p.gold, fontFamily = FontFamily.Serif, fontSize = 15.sp)
        }
        Spacer(Modifier.height(12.dp))
    }
    if(ducksVisible) DuckOverlay()
    }
}

@Composable
private fun CreditRow(icon: String, name: String, role: String, p: Palette, compact: Boolean = false) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 7.dp)) {
        Box(
            Modifier
                .size(if (compact) 40.dp else 46.dp)
                .clip(CircleShape)
                .border(1.dp, p.gold, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Text(icon, fontSize = if (compact) 20.sp else 22.sp, color = p.gold)
        }
        Spacer(Modifier.width(9.dp))
        Column(Modifier.weight(1f)) {
            Text(name, color = readableOn(p.panel), fontFamily = FontFamily.Serif, fontWeight = FontWeight.Black, fontSize = if (compact) 14.sp else 16.sp, maxLines = 1)
            Text(role, color = p.gold, fontSize = if (compact) 11.sp else 12.sp, lineHeight = 15.sp)
        }
    }
}

@Composable
private fun DottedDivider(p: Palette) {
    Canvas(Modifier.fillMaxWidth().height(1.dp)) {
        val dot = 1.dp.toPx()
        var x = 0f
        while (x < size.width) {
            drawCircle(p.outline, radius = dot, center = androidx.compose.ui.geometry.Offset(x, size.height / 2))
            x += 6.dp.toPx()
        }
    }
}

@Composable
private fun AboutActionButton(icon: String, title: String, subtitle: String, background: Color, p: Palette, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(background)
            .border(1.dp, p.gold, RoundedCornerShape(10.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(icon, fontSize = 24.sp)
        Spacer(Modifier.width(11.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = Color(0xFFF2E2BC), fontFamily = FontFamily.Serif, fontWeight = FontWeight.Black, fontSize = 16.sp)
            Text(subtitle, color = p.gold, fontSize = 12.sp)
        }
        Text("›", color = p.gold, fontSize = 34.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable private fun PageHeader(title:String,p:Palette,onBack:()->Unit,trailing: (@Composable () -> Unit)? = null){Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){PageBack(onBack,p);Spacer(Modifier.width(10.dp));Text(title.uppercase(),fontFamily=FontFamily.Serif,fontWeight=FontWeight.Black,fontSize=24.sp,color=p.pageText,modifier=Modifier.weight(1f));trailing?.invoke()}}
@Composable private fun PageBack(onBack:()->Unit,p:Palette){
    Button(onClick=onBack,shape=RoundedCornerShape(9.dp),colors=ButtonDefaults.buttonColors(containerColor=p.panel),contentPadding=PaddingValues(0.dp),modifier=Modifier.size(58.dp).border(2.dp,p.outline,RoundedCornerShape(9.dp))){
        Canvas(Modifier.size(35.dp)){
            val c=Color(0xFFF1DEAC);val sw=4.5.dp.toPx()
            val y=size.height*.52f
            drawLine(c,androidx.compose.ui.geometry.Offset(size.width*.18f,y),androidx.compose.ui.geometry.Offset(size.width*.84f,y),sw,StrokeCap.Round)
            drawLine(c,androidx.compose.ui.geometry.Offset(size.width*.18f,y),androidx.compose.ui.geometry.Offset(size.width*.43f,size.height*.25f),sw,StrokeCap.Round)
            drawLine(c,androidx.compose.ui.geometry.Offset(size.width*.18f,y),androidx.compose.ui.geometry.Offset(size.width*.43f,size.height*.79f),sw,StrokeCap.Round)
            drawLine(c,androidx.compose.ui.geometry.Offset(size.width*.44f,size.height*.38f),androidx.compose.ui.geometry.Offset(size.width*.72f,size.height*.38f),sw*.55f,StrokeCap.Round)
        }
    }
}

@Composable
private fun InputPanel(
    product: String,
    onProductChange: (String) -> Unit,
    quantity: String,
    onQuantityChange: (String) -> Unit,
    onAdd: () -> Unit,
    expanded: Boolean,
    onExpandedChange: (Boolean) -> Unit,
    p: Palette
) {
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(p.panel)
            .border(1.dp,p.outline,RoundedCornerShape(10.dp)).padding(10.dp)
    ) {
        Row(verticalAlignment=Alignment.CenterVertically){
            Text("LÄGG TILL PRODUKT",color=p.gold,fontFamily=FontFamily.Serif,fontWeight=FontWeight.Black,fontSize=13.sp,modifier=Modifier.weight(1f))
            Box(Modifier.size(32.dp).clip(RoundedCornerShape(7.dp)).background(p.gold.copy(alpha=.15f)).border(1.dp,p.gold,RoundedCornerShape(7.dp)).clickable{onExpandedChange(!expanded)},contentAlignment=Alignment.Center){Text(if(expanded)"−" else "+",color=p.gold,fontSize=22.sp,fontWeight=FontWeight.Black)}
        }
        if(expanded){
            Spacer(Modifier.height(8.dp))
            BoxWithConstraints(Modifier.fillMaxWidth()){
                val narrow=maxWidth<350.dp;val gap=8.dp
                Row(verticalAlignment=Alignment.Bottom){
                    Column(Modifier.weight(if(narrow)1.35f else 1.45f)){InputLabel("product","PRODUKT",p);Spacer(Modifier.height(6.dp));RetroField(product,onProductChange,"Namn",Modifier.fillMaxWidth().height(58.dp),p,onDone=onAdd)}
                    Spacer(Modifier.width(gap))
                    Column(Modifier.weight(if(narrow).95f else 1f)){InputLabel("balance","MÄNGD",p);Spacer(Modifier.height(6.dp));RetroField(quantity,onQuantityChange,"Valfri mängd",Modifier.fillMaxWidth().height(58.dp),p,onDone=onAdd,placeholderSize=if(narrow)13.sp else 14.sp)}
                    Spacer(Modifier.width(gap));RetroButton("✓",onAdd,p,modifier=Modifier.size(58.dp),compact=true)
                }
            }
        }
    }
}

@Composable
private fun InputLabel(icon: String, text: String, p: Palette) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        if (icon == "balance") {
            BalanceScaleIcon(color = p.gold, modifier = Modifier.size(16.dp))
        } else if (icon == "product") {
            ProductBoxIcon(color = p.gold, modifier = Modifier.size(16.dp))
        } else {
            Text(icon, color = p.gold, fontFamily = FontFamily.Serif, fontWeight = FontWeight.Black, fontSize = 15.sp)
        }
        Spacer(Modifier.width(5.dp))
        Text(
            text = text,
            color = p.gold,
            fontFamily = FontFamily.Serif,
            fontWeight = FontWeight.Black,
            fontSize = 13.sp,
            maxLines = 1
        )
        Spacer(Modifier.width(7.dp))
        HorizontalDivider(
            modifier = Modifier.weight(1f),
            thickness = 1.dp,
            color = p.gold
        )
    }
}


@Composable
private fun EditListDialog(list:ShoppingListData,p:Palette,onDismiss:()->Unit,onSave:(String,String,Long)->Unit){
    var name by remember{mutableStateOf(list.name.take(40))}
    var icon by remember{mutableStateOf(list.icon)}
    var color by remember{mutableStateOf(list.iconColorHex)}
    AlertDialog(onDismissRequest=onDismiss,containerColor=p.paper,
        title={Text("REDIGERA LISTA",fontFamily=FontFamily.Serif,fontWeight=FontWeight.Black,color=p.text)},
        text={Column(Modifier.heightIn(max=520.dp).verticalScroll(rememberScrollState())){
            RetroField(name,{name=it.take(40)},"Listnamn",Modifier.fillMaxWidth(),p)
            Spacer(Modifier.height(12.dp));Text("VÄLJ FÄRG",fontWeight=FontWeight.Black,color=p.text)
            Spacer(Modifier.height(7.dp));Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){iconColors.forEach{c->Box(Modifier.size(38.dp).clip(CircleShape).background(Color(c)).border(if(c==color)4.dp else 1.dp,if(c==color)p.gold else p.outline,CircleShape).clickable{color=c})}}
            Spacer(Modifier.height(12.dp));Text("VÄLJ IKON",fontWeight=FontWeight.Black,color=p.text)
            Spacer(Modifier.height(7.dp));listIcons.chunked(4).forEach{row->Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(7.dp)){row.forEach{i->Box(Modifier.weight(1f).aspectRatio(1f).clip(RoundedCornerShape(8.dp)).background(if(i==icon)Color(color) else p.paper2).border(if(i==icon)3.dp else 1.dp,if(i==icon)p.gold else p.outline,RoundedCornerShape(8.dp)).clickable{icon=i},contentAlignment=Alignment.Center){Text(i,fontSize=25.sp)}}};Spacer(Modifier.height(7.dp))}
        }},
        confirmButton={RetroButton("SPARA",{if(name.isNotBlank())onSave(name,icon,color)},p)},
        dismissButton={RetroButton("AVBRYT",onDismiss,p,danger=true)})
}

@Composable
private fun ProductBoxIcon(color:Color,modifier:Modifier=Modifier){
    Canvas(modifier){
        val sw=1.5.dp.toPx()
        val left=size.width*.18f;val right=size.width*.82f;val top=size.height*.25f;val bottom=size.height*.82f
        drawRect(color,topLeft=androidx.compose.ui.geometry.Offset(left,top),size=androidx.compose.ui.geometry.Size(right-left,bottom-top),style=Stroke(sw))
        drawLine(color,androidx.compose.ui.geometry.Offset(left,top),androidx.compose.ui.geometry.Offset(size.width*.5f,size.height*.08f),sw,StrokeCap.Round)
        drawLine(color,androidx.compose.ui.geometry.Offset(right,top),androidx.compose.ui.geometry.Offset(size.width*.5f,size.height*.08f),sw,StrokeCap.Round)
        drawLine(color,androidx.compose.ui.geometry.Offset(size.width*.5f,size.height*.08f),androidx.compose.ui.geometry.Offset(size.width*.5f,bottom),sw,StrokeCap.Round)
    }
}

@Composable
private fun DuckOverlay(){
    BoxWithConstraints(Modifier.fillMaxSize()){
        val width=constraints.maxWidth.toFloat()
        val height=constraints.maxHeight.toFloat()
        val seeds=remember{List(12){i->
            val r=Random(i*7919+330)
            DuckSeed(
                startX=r.nextFloat()*(width.coerceAtLeast(1f)-70f).coerceAtLeast(1f),
                startY=r.nextFloat()*(height.coerceAtLeast(1f)-70f).coerceAtLeast(1f),
                vx=(90f+r.nextFloat()*130f)*(if(r.nextBoolean())1 else -1),
                vy=(80f+r.nextFloat()*140f)*(if(r.nextBoolean())1 else -1),
                size=22+r.nextInt(8),
                spin=(35f+r.nextFloat()*90f)*(if(r.nextBoolean())1 else -1)
            )
        }}
        seeds.forEachIndexed{i,d->BouncingDuck(i,d,width,height)}
    }
}

private data class DuckSeed(val startX:Float,val startY:Float,val vx:Float,val vy:Float,val size:Int,val spin:Float)

@Composable
private fun BouncingDuck(index:Int,seed:DuckSeed,width:Float,height:Float){
    var x by remember(index,width){mutableStateOf(seed.startX.coerceIn(0f,(width-55f).coerceAtLeast(0f)))}
    var y by remember(index,height){mutableStateOf(seed.startY.coerceIn(0f,(height-55f).coerceAtLeast(0f)))}
    var vx by remember(index){mutableStateOf(seed.vx)}
    var vy by remember(index){mutableStateOf(seed.vy)}
    var rotation by remember(index){mutableStateOf(0f)}
    LaunchedEffect(index,width,height){
        var last=withFrameNanos{it}
        while(true){
            val now=withFrameNanos{it}
            val dt=((now-last)/1_000_000_000f).coerceAtMost(.035f);last=now
            x+=vx*dt;y+=vy*dt;rotation=(rotation+seed.spin*dt)%360f
            val maxX=(width-58f).coerceAtLeast(0f);val maxY=(height-58f).coerceAtLeast(0f)
            if(x<=0f){x=0f;vx=abs(vx)} else if(x>=maxX){x=maxX;vx=-abs(vx)}
            if(y<=0f){y=0f;vy=abs(vy)} else if(y>=maxY){y=maxY;vy=-abs(vy)}
        }
    }
    Text("🦆",fontSize=seed.size.sp,modifier=Modifier.graphicsLayer{translationX=x;translationY=y;rotationZ=rotation})
}

@Composable
private fun BalanceScaleIcon(color: Color, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val sw = 1.5.dp.toPx()
        val cx = size.width * .5f
        drawLine(color, androidx.compose.ui.geometry.Offset(cx, size.height * .14f), androidx.compose.ui.geometry.Offset(cx, size.height * .78f), sw, StrokeCap.Round)
        drawLine(color, androidx.compose.ui.geometry.Offset(size.width * .18f, size.height * .32f), androidx.compose.ui.geometry.Offset(size.width * .82f, size.height * .32f), sw, StrokeCap.Round)
        drawLine(color, androidx.compose.ui.geometry.Offset(size.width * .34f, size.height * .32f), androidx.compose.ui.geometry.Offset(size.width * .22f, size.height * .60f), sw, StrokeCap.Round)
        drawLine(color, androidx.compose.ui.geometry.Offset(size.width * .66f, size.height * .32f), androidx.compose.ui.geometry.Offset(size.width * .78f, size.height * .60f), sw, StrokeCap.Round)
        drawArc(color, 0f, 180f, false, androidx.compose.ui.geometry.Offset(size.width * .08f, size.height * .50f), androidx.compose.ui.geometry.Size(size.width * .28f, size.height * .25f), style = Stroke(sw))
        drawArc(color, 0f, 180f, false, androidx.compose.ui.geometry.Offset(size.width * .64f, size.height * .50f), androidx.compose.ui.geometry.Size(size.width * .28f, size.height * .25f), style = Stroke(sw))
        drawLine(color, androidx.compose.ui.geometry.Offset(size.width * .30f, size.height * .84f), androidx.compose.ui.geometry.Offset(size.width * .70f, size.height * .84f), sw, StrokeCap.Round)
    }
}

@Composable private fun RetroTitle(text:String,p:Palette){Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(7.dp)).background(p.green).padding(9.dp),contentAlignment=Alignment.Center){Text(text,fontFamily=FontFamily.Serif,fontWeight=FontWeight.Black,fontSize=17.sp,color=Color(0xFFE8D7A8))}}

@Composable private fun EditButton(onClick:()->Unit,p:Palette){
    Button(
        onClick=onClick,
        shape=RoundedCornerShape(8.dp),
        colors=ButtonDefaults.buttonColors(containerColor=p.panel,contentColor=Color(0xFFF6E8C3)),
        contentPadding=PaddingValues(0.dp),
        modifier=Modifier.size(50.dp).border(2.dp,p.outline,RoundedCornerShape(8.dp))
    ){
        Canvas(Modifier.size(27.dp)){
            val c=Color(0xFFF6E8C3)
            val sw=3.dp.toPx()
            drawLine(c,androidx.compose.ui.geometry.Offset(size.width*.25f,size.height*.74f),androidx.compose.ui.geometry.Offset(size.width*.70f,size.height*.29f),sw,StrokeCap.Round)
            drawLine(c,androidx.compose.ui.geometry.Offset(size.width*.34f,size.height*.83f),androidx.compose.ui.geometry.Offset(size.width*.79f,size.height*.38f),sw,StrokeCap.Round)
            drawLine(c,androidx.compose.ui.geometry.Offset(size.width*.70f,size.height*.29f),androidx.compose.ui.geometry.Offset(size.width*.79f,size.height*.38f),sw,StrokeCap.Round)
            drawLine(c,androidx.compose.ui.geometry.Offset(size.width*.24f,size.height*.75f),androidx.compose.ui.geometry.Offset(size.width*.20f,size.height*.88f),sw*.75f,StrokeCap.Round)
            drawLine(c,androidx.compose.ui.geometry.Offset(size.width*.20f,size.height*.88f),androidx.compose.ui.geometry.Offset(size.width*.34f,size.height*.83f),sw*.75f,StrokeCap.Round)
        }
    }
}

@Composable private fun DeleteButton(onClick:()->Unit,p:Palette){
    Button(onClick,shape=RoundedCornerShape(8.dp),colors=ButtonDefaults.buttonColors(containerColor=p.red,contentColor=Color(0xFFF6E8C3)),contentPadding=PaddingValues(0.dp),modifier=Modifier.size(50.dp)){
        Canvas(Modifier.size(27.dp)){
            val c=Color(0xFFF6E8C3);val sw=3.1.dp.toPx()
            drawLine(c,androidx.compose.ui.geometry.Offset(size.width*.25f,size.height*.28f),androidx.compose.ui.geometry.Offset(size.width*.75f,size.height*.28f),sw,StrokeCap.Round)
            drawLine(c,androidx.compose.ui.geometry.Offset(size.width*.40f,size.height*.18f),androidx.compose.ui.geometry.Offset(size.width*.60f,size.height*.18f),sw,StrokeCap.Round)
            val path=Path().apply{moveTo(size.width*.30f,size.height*.34f);lineTo(size.width*.35f,size.height*.82f);lineTo(size.width*.65f,size.height*.82f);lineTo(size.width*.70f,size.height*.34f)}
            drawPath(path,c,style=Stroke(width=sw,cap=StrokeCap.Round))
            drawLine(c,androidx.compose.ui.geometry.Offset(size.width*.43f,size.height*.43f),androidx.compose.ui.geometry.Offset(size.width*.45f,size.height*.72f),sw*.72f,StrokeCap.Round)
            drawLine(c,androidx.compose.ui.geometry.Offset(size.width*.57f,size.height*.43f),androidx.compose.ui.geometry.Offset(size.width*.55f,size.height*.72f),sw*.72f,StrokeCap.Round)
        }
    }
}
@Composable private fun SquareIcon(text:String,onClick:()->Unit,p:Palette,large:Boolean=false){Button(onClick,shape=RoundedCornerShape(8.dp),colors=ButtonDefaults.buttonColors(containerColor=p.panel,contentColor=Color(0xFFEAD7A8)),contentPadding=PaddingValues(0.dp),modifier=Modifier.size(if(large)56.dp else 44.dp).border(2.dp,p.outline,RoundedCornerShape(8.dp))){Text(text,fontSize=if(large)31.sp else 22.sp,fontWeight=FontWeight.Black)}}
@Composable private fun EditDialog(item:ShoppingItem,p:Palette,onDismiss:()->Unit,onSave:(String,String)->Unit){var n by remember{mutableStateOf(item.name)};var q by remember{mutableStateOf(item.quantity)};AlertDialog(onDismissRequest=onDismiss,containerColor=p.paper,title={Text("REDIGERA VARA",fontFamily=FontFamily.Serif,fontWeight=FontWeight.Black,color=p.text)},text={Column{RetroField(n,{n=it},"Vara",Modifier.fillMaxWidth(),p);Spacer(Modifier.height(9.dp));RetroField(q,{q=it},"Mängd/enhet, t.ex. 2 paket",Modifier.fillMaxWidth(),p)}},confirmButton={RetroButton("SPARA",{if(n.isNotBlank())onSave(n,q)},p)},dismissButton={RetroButton("AVBRYT",onDismiss,p,danger=true)})}
@Composable private fun ConfirmDialog(title:String,text:String,p:Palette,onDismiss:()->Unit,onConfirm:()->Unit,confirmLabel:String="BEKRÄFTA"){AlertDialog(onDismissRequest=onDismiss,containerColor=p.paper,title={Text(title,fontFamily=FontFamily.Serif,fontWeight=FontWeight.Black,color=p.text)},text={Text(text,color=p.text)},confirmButton={RetroButton(confirmLabel,onConfirm,p,danger=true)},dismissButton={RetroButton("AVBRYT",onDismiss,p)})}
@Composable private fun RetroField(value:String,onValueChange:(String)->Unit,placeholder:String,modifier:Modifier,p:Palette,onDone:()->Unit={},placeholderSize:androidx.compose.ui.unit.TextUnit=16.sp){OutlinedTextField(value,onValueChange,modifier=modifier,singleLine=true,placeholder={Text(placeholder,color=p.muted,fontSize=placeholderSize,maxLines=1)},keyboardOptions=KeyboardOptions(capitalization=KeyboardCapitalization.Sentences,imeAction=ImeAction.Done),keyboardActions=KeyboardActions(onDone={onDone()}),shape=RoundedCornerShape(8.dp),colors=OutlinedTextFieldDefaults.colors(focusedTextColor=p.text,unfocusedTextColor=p.text,focusedBorderColor=p.gold,unfocusedBorderColor=p.outline,cursorColor=p.gold,focusedContainerColor=p.paper,unfocusedContainerColor=p.paper))}
@Composable private fun RetroButton(text:String,onClick:()->Unit,p:Palette,modifier:Modifier=Modifier,compact:Boolean=false,danger:Boolean=false){Button(onClick,modifier=modifier,shape=RoundedCornerShape(8.dp),colors=ButtonDefaults.buttonColors(containerColor=if(danger)p.red else p.green,contentColor=Color(0xFFF4E4BA)),contentPadding=PaddingValues(horizontal=if(compact)10.dp else 14.dp,vertical=if(compact)9.dp else 13.dp)){Text(text,fontFamily=FontFamily.Serif,fontWeight=FontWeight.Black,fontSize=if(compact)13.sp else 17.sp)}}
private fun capitalized(s:String)=s.trim().replaceFirstChar{if(it.isLowerCase())it.titlecase()else it.toString()}
