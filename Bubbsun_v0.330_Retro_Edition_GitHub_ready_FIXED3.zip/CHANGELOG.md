# Bubbsun v0.330 FIXED3

- Tog bort den utskrivna mejladressen från Om-sidan.
- Rättade kryssrutornas färger i ljust tema.
- Flyttade färgvalet ovanför ikonvalet när en lista skapas.
- Tog bort draghandtagen från listor och produkter.
- Långtryck på hela listkortet aktiverar flyttläge; vanligt tryck öppnar listan.
- Långtryck på produktraden, utanför kryssrutan, aktiverar flyttläge; vanligt tryck redigerar produkten.
- Dragna listor och produkter motkompenseras när ordningen ändras så de stannar under fingret.
- Övriga rader flyttar undan och visar den nya placeringen medan man drar.
