# Bubbsun v0.400 – Polish & kvalitet

- Ny retrodesignad inställningssida.
- Svenska väljs automatiskt på svenska telefoner; engelska används på övriga telefoner.
- Språket kan ändras mellan Svenska och English i Inställningar.
- Ny inställning för bekräftelsen ”Avsluta Bubbsun?”.
- Statistik kan nollställas från Inställningar och återställningsknappen är borttagen från statistiksidan.
- Androids tillbaka-knapp visar ”Avsluta Bubbsun?” på startsidan.
- Listor kan redigeras med namn, ikon och färg.
- Dynamisk textstorlek för långa listnamn.
- Panelen ”Lägg till produkt” kan minimeras och expanderas; valt läge sparas.
- Förbättrad layout för större textstorlekar.
- Versionsnummer uppdaterat till 0.400.
