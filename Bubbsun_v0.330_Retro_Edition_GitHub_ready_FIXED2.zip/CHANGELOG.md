# Bubbsun v0.330 FIXED2

- Listkort följer fingret vid långtryck och drag.
- Lägg till-knappen ersätts av en röd TA BORT-zon under dragning.
- Bekräftelse krävs innan en lista tas bort.
- Redigera-knappen borttagen från listöversikten.
- Redigera-knappen inne i en lista har samma storlek och rena kanter.
- Bättre kontrast för Markera alla/Avbryt i ljust tema.
- Nollställ statistik ligger längst ned i den scrollbara statistiken.
- Frasses tidigare rena transparenta utklipp återställt.
- Påskägget har 12 ankor med olika riktningar, hastigheter, rotation och studs mot skärmkanterna.
